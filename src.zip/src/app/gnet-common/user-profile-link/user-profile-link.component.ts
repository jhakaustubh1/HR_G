import { Component, Input, OnInit, TemplateRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { isValidGuid } from '../../shared/utils';
@Component({
  selector: 'app-user-profile-link',
  templateUrl: './user-profile-link.component.html',
  styleUrls: ['./user-profile-link.component.scss']
})
export class UserProfileLinkComponent implements OnInit {

  @Input() public userId: number;
  @Input() public displayText: string = null;

  private dialogRef: DialogRef;

  constructor(
    private _dialogService: DialogService,
    private _translationService: TranslateService) {

  }

  ngOnInit(): void {
  }

  showGnetDirectoryProfileDialog(template: TemplateRef<any>): void {
    this.dialogRef = this._dialogService.open({
      title: this._translationService.instant('Profile') + ': ' + this.displayText,
      content: template
    });
  }

  closeGnetDirectoryProfileDialog(): void {
    this.dialogRef.close();
  }

}
