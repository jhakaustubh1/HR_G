import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { GnetUtilitiesService } from '../services/gnet-utilities.service';
import { HttpClient } from '@angular/common/http';
import { User } from '../../models/user.model';
import { ApplicationService } from '../../services/application.service';

@Component({
    selector: 'app-gnet-directory-profile',
    templateUrl: './gnet-directory-profile.component.html',
    styleUrls: ['./gnet-directory-profile.component.scss']
})
export class GnetDirectoryProfileComponent implements OnInit {

    @Input() directoryProfile: any = null;
    @Input() userId: number;
    @Output() triggerDirectoryProfileClose: EventEmitter<any> = new EventEmitter<boolean>();

    constructor(
        public gnetUtilitiesService: GnetUtilitiesService,
        private _applicationService: ApplicationService
    ) { }

    ngOnInit() {
        if (this.directoryProfile == null) {
            // this._applicationService.getGNetUserById(this.userId)
            //     .subscribe(r => {
            //         // result will always be Roman when app is ran locally
            //         this.directoryProfile = r;
            //     });
        }
    }

    closeDirectoryProfile(): void {
        this.triggerDirectoryProfileClose.emit(true);
    }

    getLoading(): boolean {
        return false;//this._applicationService.loading;
    }
}
