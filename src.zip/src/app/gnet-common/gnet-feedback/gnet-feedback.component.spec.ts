import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GnetFeedbackComponent } from './gnet-feedback.component';

describe('GnetFeedbackComponent', () => {
  let component: GnetFeedbackComponent;
  let fixture: ComponentFixture<GnetFeedbackComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GnetFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GnetFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
