import {
    Component,
    OnInit,
    OnDestroy,
    AfterViewInit,
    Input,
    Output,
    ViewChild,
    ElementRef,
    EventEmitter,
    TemplateRef
} from '@angular/core';
import {
    DialogService,
    DialogRef,
    DialogCloseResult
} from '@progress/kendo-angular-dialog';

/**
 * Services
 */
import { GnetCommonService } from '../services/gnet-common.service';
import { AlertService } from '../../services/alert.service';
import { Feedback } from '../../models/feedback.model';

@Component({
    selector: 'app-gnet-feedback',
    templateUrl: './gnet-feedback.component.html',
    styleUrls: ['./gnet-feedback.component.scss']
})
export class GnetFeedbackComponent implements OnInit, AfterViewInit, OnDestroy {

    @Input() gnetUser: any;
    @Output() triggerFeedbackClose = new EventEmitter<boolean>();
    @ViewChild('feedbackComment') feedbackComment: any;
    @ViewChild('feedbackSentSuccessSwal') feedbackSentSuccessSwal: any;
    @ViewChild('feedbackSentErrorSwal') feedbackSentErrorSwal: any;
    isLoading: boolean;
    currentApplication: any;
    message: any;
    commentField: any;
    emailField: any;
    attachment: any;

    loadingScreenCapture: boolean;

    subscriptions: Array<any> = [];

    constructor(
        private _gnetCommonService: GnetCommonService,
        private dialogService: DialogService,
        private _alertService: AlertService
    ) { }

    ngOnInit() {

        this.emailField = this.gnetUser.Email;
        this.isLoading = true;
        this._gnetCommonService.getApplicationSettings()
            .subscribe(response => {
                const application = response['Data'];
                if (application) {
                    this.currentApplication = application;
                }
                this.isLoading = false;
            });
    }

    ngAfterViewInit(): void {

        setTimeout(() => {
            this.feedbackComment.nativeElement.focus();
        }, 0);
    }

    ngOnDestroy() {

        this.subscriptions.forEach(s => s.unsubscribe());
    }

    // add attachment
    handleUpload(event: any) {
        // it sends the image as a base64 string and the backend then just makes it the image it should be
        const file = event.target.files[0];
        const reader = new FileReader();

        reader.readAsDataURL(file);
        reader.onload = () => {
            const newBase64String = reader.result;
            this.attachment = newBase64String.toString().split(',')[1];
        };
    }


    showConfirmation(template: TemplateRef<any>) {

        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;

        const newWidth = windowWidth * 0.8;

        const newHeight = (windowHeight / windowWidth) * newWidth;

        const dialog: DialogRef = this.dialogService.open({
            title: 'This image may not be an exact replicate and is only used for reference.',
            content: template,
            actions: [
                { text: 'Close', primary: true }
            ],
            width: newWidth,
            height: newHeight,
            minWidth: 250
        });


        this.subscriptions.push(dialog.result.subscribe((result) => {

            if (result instanceof DialogCloseResult) {

            } else {

            }
        }));
    }


    submitFeedback(comment, email) {

        const feedback: Feedback = {
            ProfileId: this.gnetUser.ProfileId,
            UserEmail: email,
            Comment: comment,
            AppName: this.currentApplication.Name,
            ApplicationName: this.currentApplication.Name,
            JsonRequest: true,
            TypeString: 'Comment',
            Screenshot: this.attachment
        };

        this.isLoading = true;
        this.subscriptions.push(this._gnetCommonService
            .submitFeedback(feedback).subscribe(
                (response: any) => {

                    if (response.success === true) {

                        this._alertService.triggerSweetAlert({
                            swalOptions: {
                                icon: 'success',
                                title: 'Thank you for submitting your feedback.',
                                text: 'Someone will get back to you soon.'
                            }
                        });
                        this.closeFeedback();
                    } else {
                        this._alertService.triggerSweetAlert({
                            swalOptions: {
                                icon: 'error',
                                title: 'Sorry, your feedback failed to submit.',
                                text: 'Please try again later.'
                            }
                        });
                    }

                    this.isLoading = false;
                },
                (error) => {

                    this.isLoading = false;
                }));
    }


    closeFeedback(): void {

        this.triggerFeedbackClose.next(true);
    }
}
