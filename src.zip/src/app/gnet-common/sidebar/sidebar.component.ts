import {
    Component,
    OnInit,
    Input,
    Output,
    EventEmitter
} from '@angular/core';

// The sidebar content consists of an array of
// ICategory objects. This interface defines it's
// accepted properties.

interface ICategory {

    iconString?: string;
    categoryName: string;
    categoryLinks: Array<ICategoryLink>;
}

// ICategory includes an array of ICategoryLink as follows.

interface ICategoryLink {

    routePath: string;
    linkName: string;
}


@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})

export class SidebarComponent implements OnInit {

    @Input() isMainMenuOpen: boolean;
    @Output() closeSidebarMenu: EventEmitter<any> = new EventEmitter();
    sidebarCategories: Array<ICategory>;

    constructor() { }

    ngOnInit() {

        // The sidebar is dynamically generated via the following array.
        // New categories are added to the sidebar by adding additional objects
        // that follow the ICategory interface structure.

        this.sidebarCategories = [
            // This level is reserved for ICategory definitions
            {
                // iconString: 'fa-home',
                categoryName: 'Main Workflow',
                categoryLinks: [

                    // This is where we define ICategoryLink objects.
                    // Routing strings are defined in app.routing.ts
                    {
                        routePath: '/grievance-grid',
                        linkName: 'Grievances'
                    },
                    {
                        routePath: '/process-two',
                        linkName: 'Process Two'
                    }
                ]
            },
            {
                // iconString: 'fa-cog',
                categoryName: 'Admin',
                categoryLinks: [
                    {
                        routePath: '/programs',
                        linkName: 'Programs'
                    },
                    {
                        routePath: '/categories',
                        linkName: 'Categories'
                    },
                    {
                        routePath: '/grievance-types',
                        linkName: 'Grievance Types'
                    }
                ]
            }
        ];
    }

    closeMenu(): void {

        this.closeSidebarMenu.emit(false);
    }

}
