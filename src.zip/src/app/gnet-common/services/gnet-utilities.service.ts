import { Injectable, Inject, ComponentFactoryResolver, ApplicationRef, Injector, EmbeddedViewRef } from '@angular/core';
import { resolve } from 'url';
import { IPSUM_WORDS } from '../assets/ipsum-words';
@Injectable({
    providedIn: 'root'
})
export class GnetUtilitiesService {
    private _isLocal: boolean;
    private _isDevelopment: boolean;
    private _isProduction: boolean;
    private _isBdirect: boolean;
    private _baseHref: string;
    private _port: string;
    private _localhostUrl: string;
    private _gnetDevelopmentUrl: string;
    private _gnetProductionUrl: string;
    private _bdirectUrl: string;

    get isLocal() {
 return this._isLocal;
}
    get isProduction() {
 return this._isProduction;
}
    get isDevelopment() {
 return this._isDevelopment;
}
    get isBdirect() {
 return this._isBdirect;
}
    get localhostUrl() {
 return this._localhostUrl;
}
    get developmentUrl() {
 return this._gnetDevelopmentUrl;
}
    get productionUrl() {
 return this._gnetProductionUrl;
}
    get bdirectUrl() {
 return this._bdirectUrl;
}

    constructor(
        @Inject('Window') private _window: Window,
        private componentFactoryResolver: ComponentFactoryResolver,
        private appRef: ApplicationRef,
        private injector: Injector
    ) {
        this._gnetDevelopmentUrl = 'https://gnetdev.ca.aero.bombardier.net';
        this._gnetProductionUrl = 'https://gnet.ca.aero.bombardier.net';
        this._bdirectUrl = 'https://gnet.aero.bombardier.com';

        // determine environment variables
        this._isLocal = this._window.location.hostname.indexOf('localhost') > -1;
        this._isDevelopment = this._window.location.hostname.indexOf('gnetdev.ca.aero.bombardier.net') > -1;
        this._isProduction = this._window.location.hostname.indexOf('gnet.ca.aero.bombardier.net') > -1;
        this._isBdirect = this._window.location.hostname.indexOf('gnet.aero.bombardier.com') > -1;
        this._baseHref = this._window.location.pathname;
        this._port = this._window.location.port;
        this._localhostUrl = 'http://localhost:' + this._port;
    }

    /**
     * Returns the base application url. Appends the path if provided.
     *
     * @param path
     */
    getApplicationUrl(path?: string): string {
        let newUrl = new URL(this._getEnvironmentUrl(), path ? path : this._baseHref).toString();
        // normalize end of url with slash
        if (newUrl[newUrl.length - 1] !== '/') {
            newUrl += '/';
        }
        return newUrl;
    }

    /**
     * Returns the base GNet domain url. Appends the path if provided.
     *
     * @param path
     */
    getGnetUrl(path?: string): string {

        let newUrl = this._isLocal || this._isDevelopment ? this._gnetDevelopmentUrl : this._gnetProductionUrl;
        if (path) {
            const hasSlash = path.charAt(0) === '/';
            if (!hasSlash) {
                path = '/' + path;
            }
            newUrl += path;
        }

        return newUrl;
    }

    // Rewrites URL for BDirect
    getBdirectURL(currentUrl): string {

        if (this._isBdirect && currentUrl) {

            currentUrl = currentUrl.replace('gnet.ca.aero.bombardier.net', 'gnet.aero.bombardier.com');
        }

        return currentUrl;
    }

    /**
     * Escapes all quotes and apostrophes in a javascript string.
     *
     * @param str
     */
    escapeString(str) {

        return (str + '').replace(/\\([\s\S])|(")/g, '\\$1$2');
    }

    /**
     * Generates a random ipsum sentence of length.
     *
     * @param length
     */
    loremIpsum(length) {

        const extracted = [];
        for (let i = 0; i < length; i++) {
            extracted.push(IPSUM_WORDS[Math.floor(Math.random() * IPSUM_WORDS.length)]);
        }

        return extracted.join(' ');
    }

    /**
     * Determines the correct base url to return depending on the environment.
     */
    private _getEnvironmentUrl(): string {

        if (this.isLocal) {
            return this.localhostUrl;
        } if (this.isDevelopment) {
            return this.developmentUrl;
        } if (this.isProduction) {
            return this.productionUrl;
        } if (this.isBdirect) {
            return this.bdirectUrl;
        }
    }
}

