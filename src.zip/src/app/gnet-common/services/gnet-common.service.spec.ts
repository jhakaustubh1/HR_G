import { TestBed, inject } from '@angular/core/testing';

import { GnetCommonService } from './gnet-common.service';

describe('GnetService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GnetCommonService]
    });
  });

  it('should be created', inject([GnetCommonService], (service: GnetCommonService) => {
    expect(service).toBeTruthy();
  }));
});
