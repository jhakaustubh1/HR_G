import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GnetUtilitiesService } from './gnet-utilities.service';
import { HttpResponseMessage } from '../../models/http-response-message.model';
import { GNetUser } from '../../models/gnet-user.model';

@Injectable({
    providedIn: 'root'
})
export class GnetCommonService {
    constructor(
        private _http: HttpClient,
        private _gnetUtilitiesService: GnetUtilitiesService
    ) {}

    public getUser() {
        const url = this._gnetUtilitiesService.getApplicationUrl('api/gnet-user');
        return this._http.get(url);
    }

    public getApplicationSettings() {
        return this._http.get('api/settings');
    }

    public getUserApplications() {
        return this._http.get(this._gnetUtilitiesService.getGnetUrl('api/user/me/applications'));
    }

    public getUserApplicationNotifications() {
        return this._http.get(this._gnetUtilitiesService.getGnetUrl('api/user/me/notifications'));
    }

    public getNotifications() {
        return this._http.get(this._gnetUtilitiesService.getGnetUrl('api/gnet/notifications'));
    }
    public logout() {
        return this._http.get(this._gnetUtilitiesService.getGnetUrl('api/user/logout'));
    }

    public readNotification(notification) {
        return this._http.put(this._gnetUtilitiesService.getGnetUrl('api/user/me/notifications/' + notification.Id), null, null);
    }

    public getGnetDirectoryProfile(gnetUser: GNetUser) {
        if (this._gnetUtilitiesService.isLocal) {
            const _localUrl = this._gnetUtilitiesService.getGnetUrl(`api/user/profile/${gnetUser.PicassoNumber}`);
            return this._http.get<HttpResponseMessage>(_localUrl);
        }

        const _Url = this._gnetUtilitiesService.getGnetUrl(`api/directory/profile/${gnetUser.ProfileId}`);
        return this._http.get<HttpResponseMessage>(_Url);
    }

    /**
     * Send POST request to submit user's feedback
     *
     * @param feedback
     */
    public submitFeedback(feedback) {
        return this._http.post(this._gnetUtilitiesService.getGnetUrl('api/reportBug'), feedback);
    }

    /**
     * Send DELETE request to remove a user's notification
     *
     * @param notification
     */
    public removeNotification(notification) {
        return this._http.delete(this._gnetUtilitiesService.getGnetUrl('api/user/me/notifications/' + notification.Id));
    }
}
