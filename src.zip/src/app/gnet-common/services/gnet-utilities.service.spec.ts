import { TestBed, inject } from '@angular/core/testing';

import { GnetUtilitiesService } from './gnet-utilities.service';

describe('GnetUtilitiesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GnetUtilitiesService]
    });
  });

  it('should be created', inject([GnetUtilitiesService], (service: GnetUtilitiesService) => {
    expect(service).toBeTruthy();
  }));
});
