import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { ViewChild } from '@angular/core';
import { SwalComponent, SwalPortalTargets } from '@sweetalert2/ngx-sweetalert2';
import { AlertOptions, AlertService } from '../../services/alert.service';
import { SweetAlertIcon, SweetAlertOptions } from 'sweetalert2';
import { Utils } from '../../shared/utils';

@Component({
    selector: 'app-gnet-alerts',
    templateUrl: './gnet-alerts.component.html',
    styleUrls: ['./gnet-alerts.component.scss']
})
export class GnetAlertsComponent implements OnInit, OnDestroy {

    @ViewChild('swal', { static: true }) swal: SwalComponent;
    options: AlertOptions;
    subscriptions: Subscription[] = [];

    constructor(
        private _alertService: AlertService,
        public readonly swalTargets: SwalPortalTargets
    ) { }

    ngOnInit() {
        this.options = { swalOptions: {} };

        this.subscriptions.push(this._alertService.sweetAlert$.subscribe(
            (sweetAlertObj: AlertOptions) => {
                if (sweetAlertObj) {
                    this.options = Object.assign({}, sweetAlertObj);
                    const newOptions = Utils.assignObjectWithMissingPropertiesAsNull(this.swal.swalOptions, sweetAlertObj.swalOptions);
                    this.swal.swalOptions = newOptions;
                    setTimeout(() => this.swal.fire().then((r) => {
                        if (this.options.callbacks && this.options.callbacks.then) {
                            this.options.callbacks.then(r);
                        }
                    }), 100);
                }
            }
        ));
    }

    ngOnDestroy(): void {
        this.subscriptions.forEach(s => s.unsubscribe());
    }
}
