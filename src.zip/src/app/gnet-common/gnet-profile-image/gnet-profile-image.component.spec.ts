import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GnetProfileImageComponent } from './gnet-profile-image.component';

describe('GnetProfileImageComponent', () => {
  let component: GnetProfileImageComponent;
  let fixture: ComponentFixture<GnetProfileImageComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GnetProfileImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GnetProfileImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
