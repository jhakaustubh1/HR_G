import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'app-gnet-profile-image',
    templateUrl: './gnet-profile-image.component.html',
    styleUrls: ['./gnet-profile-image.component.scss']
})
export class GnetProfileImageComponent implements OnInit {

    @Input() profileImage: any;

    constructor() { }

    ngOnInit() {
    }

}
