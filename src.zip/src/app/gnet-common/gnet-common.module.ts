import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { GnetFeedbackComponent } from './gnet-feedback/gnet-feedback.component';
import { GnetNotificationsComponent } from './gnet-notifications/gnet-notifications.component';
import { GnetAlertsComponent } from './gnet-alerts/gnet-alerts.component';
import { GnetDirectoryProfileComponent } from './gnet-directory-profile/gnet-directory-profile.component';
import { GnetProfileComponent } from './gnet-profile/gnet-profile.component';
import { GnetProfileImageComponent } from './gnet-profile-image/gnet-profile-image.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { ToolbarComponent } from './toolbar/toolbar.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { GnetLangSelectComponent } from './gnet-lang-select/gnet-lang-select.component';
import { UserProfileLinkComponent } from './user-profile-link/user-profile-link.component';
import { UploadsModule } from '@progress/kendo-angular-upload';

@NgModule({
    declarations: [
        SidebarComponent,
        ToolbarComponent,
        NotFoundComponent,
        GnetDirectoryProfileComponent,
        GnetFeedbackComponent,
        GnetNotificationsComponent,
        GnetAlertsComponent,
        GnetProfileComponent,
        GnetProfileImageComponent,
        GnetLangSelectComponent,
        UserProfileLinkComponent
    ],
    imports: [
        UploadsModule,
        SharedModule
    ],
    exports: [
        SidebarComponent,
        ToolbarComponent,
        NotFoundComponent,
        GnetDirectoryProfileComponent,
        GnetFeedbackComponent,
        GnetNotificationsComponent,
        GnetAlertsComponent,
        GnetProfileComponent,
        GnetProfileImageComponent,
        UserProfileLinkComponent
    ]
})
export class GnetCommonModule { }
