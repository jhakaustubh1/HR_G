import { Component, OnInit, Input } from '@angular/core';

/**
 * Services
 */
import { GnetUtilitiesService } from '../services/gnet-utilities.service';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-gnet-profile',
    templateUrl: './gnet-profile.component.html',
    styleUrls: ['./gnet-profile.component.scss']
})
export class GnetProfileComponent implements OnInit {

    @Input() gnetUser: any;

    constructor(
        public gnetUtilitiesService: GnetUtilitiesService,
        private _http: HttpClient
    ) { }

    ngOnInit() {
    }

    public logout() {
        if (this.gnetUtilitiesService.isLocal) {
            alert('Cannot Logout on localhost.');
        }
        this._http.get(this.gnetUtilitiesService.getGnetUrl('api/user/logout'))
            .subscribe(response => {
                window.location.href = this.gnetUtilitiesService.getGnetUrl();
            });
    }
}
