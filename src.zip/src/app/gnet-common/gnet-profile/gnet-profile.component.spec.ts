import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GnetProfileComponent } from './gnet-profile.component';

describe('GnetProfileComponent', () => {
  let component: GnetProfileComponent;
  let fixture: ComponentFixture<GnetProfileComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GnetProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GnetProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
