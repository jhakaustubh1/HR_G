export const gnetLang = 'gnet-lang';
