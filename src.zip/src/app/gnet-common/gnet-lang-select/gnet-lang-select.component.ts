import { Component, OnInit } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { TranslateService } from '@ngx-translate/core';
import { CookieService } from 'ngx-cookie-service';
import { gnetLang } from './gnet-lang';

@Component({
  selector: 'app-gnet-lang-select',
  templateUrl: './gnet-lang-select.component.html',
  styleUrls: ['./gnet-lang-select.component.scss']
})
export class GnetLangSelectComponent implements OnInit {

  public languageList = [
    { code: 'en', label: 'EN' },
    { code: 'fr', label: 'FR' },
    { code: 'es', label: 'ES' }
  ];

  public selected: any;

  constructor(
    private _translateService: TranslateService,
    private _cookieService: CookieService) { }

  ngOnInit(): void {
    if (this._cookieService.check(gnetLang)) {
      const cookieLang = this._cookieService.get(gnetLang);
      this.selected = this.languageList.find(ll => ll.code === cookieLang).code;
    } else {
      // default to EN
      this.selected = this.languageList[0].code;
      this._cookieService.set(gnetLang, this.selected, new Date('2999-12-31'));
      this._translateService.use(this.selected);
    }
  }

  public changeLanguage(event: MatSelectChange) {
    this._cookieService.set(gnetLang, event.value, new Date('2999-12-31'));
    this._translateService.use(event.value);
  }

}
