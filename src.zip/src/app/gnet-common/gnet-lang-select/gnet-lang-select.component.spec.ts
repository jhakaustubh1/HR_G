import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GnetLangSelectComponent } from './gnet-lang-select.component';

describe('GnetLangSelectComponent', () => {
  let component: GnetLangSelectComponent;
  let fixture: ComponentFixture<GnetLangSelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GnetLangSelectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GnetLangSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
