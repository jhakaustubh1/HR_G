import { EventEmitter, Component, OnInit, Input, Output, ViewChild, SimpleChanges, OnChanges } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, NavigationEnd } from '@angular/router';
import { DialogService, DialogRef } from '@progress/kendo-angular-dialog';
import { TemplateRef, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GnetCommonService } from '../services/gnet-common.service';
import { AlertService } from '../../services/alert.service';
import { GnetUtilitiesService } from '../services/gnet-utilities.service';
import { forkJoin, Subscription } from 'rxjs';
import { GNetUser } from '../../models/gnet-user.model';
import { AuthService } from '../../services/auth.service';
import { ApplicationService } from '../../services/application.service';
export interface ICategoryLink {
  routePath: string;
  linkName: string;
  linkKey: string;
  hasDivider?: boolean;
}
export interface ICategory {
  iconString?: string;
  categoryName: string;
  categoryKey: string;
  categoryLink: string;
  status?: boolean;
  categoryType: string;
  categoryLinks?: Array<ICategoryLink>;
}

@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss'],
})
export class ToolbarComponent implements OnInit, OnDestroy, OnChanges {
  @Input() gnetUser: GNetUser;
  @Output() openSidebarMenu: EventEmitter<any> = new EventEmitter();
  @ViewChild('toolbarSearchInput', { static: true }) toolbarSearchInput: any;
  currentRoutePaths: Array<string>;
  toolbarSearchOpen: boolean;
  feedbackDialog: DialogRef;
  directoryProfileDialog: DialogRef;
  affiliateApplication: any;
  currentGnetDirectoryProfile: any;
  subscriptions: Array<Subscription> = [];

  activeLink: string;
  sidebarCategories: Array<ICategory>;
  public hasAdminPermissions: boolean;

  // sub toolbar properties
  public activeCategoryLinks: Array<ICategoryLink>;
  public activeSubLink: string;

  constructor(
    private _router: Router,
    private _dialogService: DialogService,
    private _http: HttpClient,
    private _gnetCommonService: GnetCommonService,
    private _alertService: AlertService,
    private _authService: AuthService,
    private _applicationService: ApplicationService,
    public gnetUtilsService: GnetUtilitiesService,
    private titleService: Title
  ) {}

  ngOnInit() {
    this.subscriptions.push(this._authService.hasAdminPermissions().subscribe((r) => (this.hasAdminPermissions = r)));

    // Get current application
    this.subscriptions.push(
      this._gnetCommonService.getApplicationSettings().subscribe((response: any) => {
        this.affiliateApplication = response.Data;
        const newTitle = response.Data.Name + ' | ' + (this.gnetUtilsService.isProduction ? 'GNET' : 'GNETdev');
        this.titleService.setTitle(newTitle);
      })
    );

    this._router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        if (this.gnetUser === undefined || this.gnetUser === null) {
          this.subscriptions.push(
            forkJoin([
              this._authService.hasAdminPermissions()
            ]).subscribe((r) => {
              this.hasAdminPermissions = r[0];
              if(event.url!=="/main/create-grievance") this.loadTabs(event.url);
            })
          );
          this.subscriptions.push(
            this._applicationService.getApplicationUser().subscribe((users) => {
              this.gnetUser = users['GNetUser'];
              this.subscriptions.push(
                this._gnetCommonService.getGnetDirectoryProfile(this.gnetUser).subscribe((response: any) => {
                  this.currentGnetDirectoryProfile = response.Data;
                })
              );
            })
          );
        } else {
          if(event.url!=="/main/create-grievance") this.loadTabs(event.url);
        }
      }
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.gnetUser && !changes.gnetUser.firstChange) {
      // Get current directory Profile
      this.subscriptions.push(
        this._gnetCommonService.getGnetDirectoryProfile(this.gnetUser).subscribe((response: any) => {
          this.currentGnetDirectoryProfile = response.Data;
        })
      );
      this.subscriptions.push(this._authService.hasAdminPermissions().subscribe((r) => (this.hasAdminPermissions = r)));
    }
  }

  loadTabs(url: string): void {

      // create toolbar categories
      this.sidebarCategories = [
        {
          categoryName: 'Main',
          categoryKey: 'main',
          categoryLink: 'main',
          categoryType: null,
          status: true,
          categoryLinks:[
            {
              linkName: 'Grievances',
              linkKey: 'grievance-grid',
              routePath: '/main/grievance-grid',
            },
            {
              linkName: 'Process Two',
              linkKey: 'process-two',
              routePath: '/main/process-two',
            },           
          ]
        },
        {
          categoryName: 'Admin',
          categoryKey: 'admin',
          categoryLink: 'admin',
          categoryType: null,
          status: true,
          categoryLinks:[
            {
              linkName: 'Programs',
              linkKey: 'programs',
              routePath: '/admin/programs',
            },
            {
              linkName: 'Categories',
              linkKey: 'categories',
              routePath: '/admin/categories',
            },
            {
              linkName: 'Grievance Types',
              linkKey: 'grievance-types',
              routePath: '/admin/grievance-types',
            }
          ]
        }
      ];
      this.getPageTitle(url);
  }

  getPageTitle(url: string): string {
    const urlContents = url.split('/');

    // set active link
    if (urlContents.find((u) => u === 'main')) {
      this.activeLink = 'main';
    }
    if (urlContents.find((u) => u === 'admin')) {
      this.activeLink = 'admin';
    }

    // find url name and add category links
    const foundUrl = this.sidebarCategories.findIndex((a) => a.categoryKey === this.activeLink);
    if (foundUrl > -1) {
      this.activeCategoryLinks = this.sidebarCategories[foundUrl].categoryLinks;
    }

    // Breadcrumbs
    // Format router url into a page title.
    const string = url.replace('/', '').replace('-', ' ');

    return string.replace(/\b\w/g, (l) => l.toUpperCase());
  }

  toggleSidebarMenu(): void {
    this.openSidebarMenu.emit(true);
  }

  toggleToolbarSearch(): void {
    this.toolbarSearchOpen = !this.toolbarSearchOpen;

    // Auto focus on the input if the search input is
    // enabled.
    if (this.toolbarSearchOpen) {
      this.toolbarSearchInput.nativeElement.focus();
    }
  }

  // Triggered when user submits a search query, triggered
  // by the enter key.
  onSearchSubmit(): void {
    console.log(this.toolbarSearchInput.nativeElement.value);
  }

  showGnetFeedbackDialog(template: TemplateRef<any>): void {
    this.feedbackDialog = this._dialogService.open({
      title: 'Feedback',
      content: template,
    });
  }

  closeGnetFeedback(): void {
    this.feedbackDialog.close();
  }

  showGnetDirectoryProfileDialog(template: TemplateRef<any>): void {
    this.directoryProfileDialog = this._dialogService.open({
      title: 'Profile: ' + this.currentGnetDirectoryProfile.FullName,
      content: template,
    });
  }

  closeGnetDirectoryProfileDialog(): void {
    this.directoryProfileDialog.close();
  }

  goToGnetUserAccount(): void {
    window.open('https://gnet.ca.aero.bombardier.net/#/account/profile', '_blank');
  }

  navigateToHome(): void {
    this._router.navigate(['/']);
  }

  logoutUserFromGnet(): void {
    const currentUrl = window.location;
    if (this.gnetUtilsService.isLocal) {
      this._alertService.triggerSweetAlert({
        swalOptions: {
          icon: 'error',
          title: 'Cannot logout in localhost',
        },
      });
    } else {
      this._http.get(this.gnetUtilsService.getGnetUrl('api/user/logout')).subscribe((response) => {
        // Redirect to affiliate login with application info
        window.location.href =
          this.gnetUtilsService.getGnetUrl() +
          '/#/affiliate-login?appId=' +
          this.affiliateApplication.ApplicationId +
          '&returnUrl=' +
          currentUrl;
      });
    }
  }
}
