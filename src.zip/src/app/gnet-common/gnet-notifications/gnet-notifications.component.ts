import { Component, OnInit, Input } from '@angular/core';
import { combineLatest } from 'rxjs';

/**
 * Services
 */
import { GnetCommonService } from '../services/gnet-common.service';
import { GnetUtilitiesService } from '../services/gnet-utilities.service';

@Component({
    selector: 'app-gnet-notifications',
    templateUrl: './gnet-notifications.component.html',
    styleUrls: ['./gnet-notifications.component.scss']
})
export class GnetNotificationsComponent implements OnInit {

    @Input() gnetUser: any;
    notifications = [];
    applicationNotifications = [];
    isLoading = false;

    constructor(private _gnetCommonService: GnetCommonService, private _gnetUtilitiesService: GnetUtilitiesService) { }

    /**
     * NOT IMPLEMENTED
     * Sets user's notification to read status
     *
     * @param notification
     */
    readNotification(notification) {
        this._gnetCommonService
            .readNotification(notification.NotificationId);
    }

    /**
     * NOT IMPLEMENTED
     * Removes user's notification from notification list
     *
     * @param notification
     */
    deleteNotification(notification) {
        this.isLoading = true;
        this._gnetCommonService.removeNotification(notification)
            .subscribe(response => {
                this.isLoading = false;
            });
    }

    ngOnInit() {
        this.isLoading = true;
        if (this._gnetUtilitiesService.isLocal) {
            this.isLoading = false;
            return;
        }
        combineLatest([
            this._gnetCommonService.getNotifications(),
            this._gnetCommonService.getUserApplicationNotifications()
        ])
            .subscribe(data => {
                // need to identify these better
                const gnetNotifications = data['Data'];
                const appNotifications = data['Data'];

                if (gnetNotifications) {
                    this.notifications = gnetNotifications;
                }

                if (appNotifications) {
                    this.applicationNotifications = appNotifications;
                }

                this.isLoading = false;
            });
    }
}
