﻿
import { User } from './user.model';
import { GlobalHeadCount } from './global-head-count.model';
import { Attachment } from './attachment.model';
import { Base } from './base.model';

export class HRGrievance extends Base {
    
    public UnionRepId?: number | null = null;
    public UnionRepo?: User = null;
    public UnionRepName?: string | null = null;
    public UnionRepEmail?: string | null = null;
    public Grievors?: GlobalHeadCount[] = [];
    public GrievorClock?: string | null = null;
    public GrievorName?: string | null = null;
    public GrievanceId?: number | null = null;
    public GrievanceName?: string | null = null;
    public DateOfIncident?: Date = new Date();
    public IsRejected?: boolean = false;
    public RejectionReason?: string | null = null;
    public UnionDescrAndRemedySought?: string | null = null;
    public LocaleNumber?: number = 0;
    public GrievanceNumber?: string | null = null;
    public HRDispositionDeadline?: Date = new Date();
    public GrievanceTypeId?: number | null = null;
    public GrievanceType?: string | null = null;
    public CategoryId?: number | null = null;
    public CategoryName?: string | null = null;
    public ProgramId?: number | null = null;
    public ProgramName?: string | null = null;
    public GrievanceStatus?: string | null = null;
    public CurrentStep?: string | null = null;
    public GrievanceDepartment?: string | null = null;
    public ResolutionDate?: Date = new Date();
    public PaymentAmount?: number = 0;
    public Attachments?: Attachment[] = [];
}
