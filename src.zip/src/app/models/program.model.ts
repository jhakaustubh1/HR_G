import { Base } from './base.model';

export class Program extends Base {
    
    public Name?: string | null = null;
}
