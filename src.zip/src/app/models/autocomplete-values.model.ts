﻿


export class AutocompleteValues {
    
    public Id?: number = 0;
    public Name?: string = "";
    public DisplayText?: string = "";
    public Disabled?: boolean = false;
}
