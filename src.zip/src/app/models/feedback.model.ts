export class Feedback {
    public ProfileId: any;
    public UserEmail: string;
    public Comment: string;
    public AppName: string;
    public ApplicationName: string;
    public JsonRequest: boolean;
    public TypeString: string;
    public Screenshot: any;
}