﻿
import { Base } from './base.model';

export class GlobalHeadCount extends Base {
    
    public PersonId?: string | null = null;
    public BadgeId?: string | null = null;
    public FirstName?: string | null = null;
    public LastName?: string | null = null;
    public DepartmentName?: string | null = null;
    public ManagerName?: string | null = null;
    public HRBPName?: string | null = null;
    public JobTitle?: string | null = null;
    public Status?: string | null = null;
    public EmailAddress?: string | null = null;
    public FullName?: string = "";
}
