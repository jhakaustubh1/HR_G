﻿


export class User {
    
    public Id?: number = 0;
    public GNetProfileId?: number = 0;
    public FullName?: string = null;
    public Email?: string = null;
    public Phone?: string = null;
    public PicassoNumber?: string = null;
    public BadgeNumber?: string = null;
    public ManagerName?: string = null;
    public CreatedAt?: Date = new Date(0);
    public DeletedAt?: Date = null;
    public DeletedById?: number = null;
    public DeletedByFullName?: string = null;
    public LastUpdatedAt?: Date = null;
}
