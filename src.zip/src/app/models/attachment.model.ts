﻿
import { User } from './user.model';
import { Base } from './base.model';

export class Attachment extends Base {
    
    public OriginalFileName?: string | null = null;
    public ServerFileName?: string = "00000000-0000-0000-0000-000000000000";
    public Url?: string | null = null;
    public FileSize?: number = 0;
    public Extension?: string | null = null;
    public Mime?: string | null = null;
    public CreatedBy?: User = null;
}
