export class Validation {
    
    public Property?: string = null;
    public Error?: string = null;
}
