﻿


export class Lookup {
    
    public Id?: number = 0;
    public Text?: string | null = null;
    public Number?: string | null = null;
    public Description?: string | null = null;
    public ParentIds?: Record<string, string | null> = null;
    public Disabled?: boolean = false;
    public CreatedAt?: Date | null = null;
}
