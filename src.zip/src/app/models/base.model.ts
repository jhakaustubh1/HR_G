﻿


export class Base {
    
    public Id?: string = "00000000-0000-0000-0000-000000000000";
    public CreatedAt?: Date = null;
    public CreatedById?: number = null;
    public CreatedByFullName?: string = null;
    public DeletedAt?: Date = null;
    public DeletedById?: number = null;
    public DeletedByFullName?: string = null;
    public UpdatedAt?: Date = null;
    public UpdatedById?: number = null;
    public UpdatedByFullName?: string = null;
    public IsActive?: boolean = false;

}
