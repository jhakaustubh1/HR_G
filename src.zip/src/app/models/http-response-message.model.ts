﻿


export class HttpResponseMessage {
    
    public Data?: any = null;
    public Error?: any = null;
    public Message?: string = null;
}
