﻿
import { Base } from './base.model';

export class Category extends Base {
    
    public Name?: string | null = null;
}
