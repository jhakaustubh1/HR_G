﻿
import { Base } from './base.model';

export class Employee extends Base {
    
    public Name?: string | null = null;
    public Clock?: string | null = null;
}
