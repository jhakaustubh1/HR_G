﻿// This is not automatically generated. 
// If any changes occur to GNetUser from GNET.Common.UserService.Models, this class has to be manually updated
export class GNetUser {
    public ProfileId?: number = null;
    public ProfileLink?: string = null;
    public FirstName?: string = null;
    public LastName?: string = null;
    public BadgeNumber?: string = null;
    public PicassoNumber?: string = null;
    public Program?: string = null;
    public Email?: string = null;
    public Site?: string = null;
    public EmployeeType?: string = null;
    public Extension?: string = null;
    public MobilePhone?: string = null;
    public ProfilePicture?: string = null;
    public ProfileMime?: string = null;
    public UserRoles?: string[] = [];
    public IsSupplier?: boolean = false;
    public PermissionTimeStamp?: Date = new Date(0);
    public ReportsToId?: number = null;
    public ReportsToName?: string = null;
    public ReportsToEmail?: string = null;
    public IsRegistered?: boolean = false;
    public FullName?: string = null;
}