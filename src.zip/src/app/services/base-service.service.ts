import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BaseService {

  public get loading(): boolean {
    return this.readLoading || this.createLoading || this.updateLoading || this.deleteLoading;
  }

  protected readDataCompleteHandler = {
    error: () => {
      this.readLoading = false;
    },
    complete: () => {
      this.readLoading = false;
    },
  };
  protected createDataCompleteHandler = {
    error: () => {
      this.createLoading = false;
    },
    complete: () => {
      this.createLoading = false;
    },
  };
  protected updateDataCompleteHandler = {
    error: () => {
      this.updateLoading = false;
    },
    complete: () => {
      this.updateLoading = false;
    },
  };
  protected deleteDataCompleteHandler = {
    error: () => {
      this.deleteLoading = false;
    },
    complete: () => {
      this.deleteLoading = false;
    },
  };
  protected readLoading: boolean;
  protected createLoading: boolean;
  protected updateLoading: boolean;
  protected deleteLoading: boolean;
  private loaders = 0;

    public resetLoaders(): void {
        this.loaders = 0;
    }

    protected addLoader(): void {
        if (this.loaders < 0) {
            this.loaders = 0;
        }
        this.loaders++;
    }

    protected removeLoader(): void {
        this.loaders--;
        if (this.loaders < 0) {
            this.loaders = 0;
        }
    }
}
