import { TestBed } from '@angular/core/testing';

import { SubToolbarService } from './sub-toolbar.service';

describe('SubToolbarService', () => {
  let service: SubToolbarService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SubToolbarService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
