import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpErrorResponse
} from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { gnetLang } from '../gnet-common/gnet-lang-select/gnet-lang';


@Injectable({
    providedIn: 'root'
})
export class HttpRequestInterceptorService implements HttpInterceptor {

    constructor(
        private _router: Router,
        private _cookieService: CookieService
    ) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        let lang = this._cookieService.get(gnetLang);
        if (!lang) {
            lang = 'en';
        }

        request = request.clone({
            withCredentials: true,
            headers: request.headers.set('Accept-Language', lang)
        });

        return next.handle(request).pipe(
            catchError((error: HttpErrorResponse) => {

                if (error.status === 401 || error.status === 403) {
                    const location = error.headers.get('location');
                    if (location != null) {
                        window.open(location, '_self');
                        return;
                    }
                }
                return throwError(error);
            })
        );
    }
}
