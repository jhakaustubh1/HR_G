import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { State, toDataSourceRequestString } from '@progress/kendo-data-query';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { handleError, Utils } from '../shared/utils';

@Injectable({
	providedIn: 'root',
})
export class ExportService {
	public loading = false;

	constructor(private _http: HttpClient) {}
	// eslint-disable-next-line @typescript-eslint/member-ordering
	private defaultCompleteHandler = {
		error: () => {
			this.loading = false;
		},
		complete: () => {
			this.loading = false;
		},
	};
	public exportGrievanceTypeGridToExcel(state: State): void {
		const url = `api/export/grievance-type?${toDataSourceRequestString(state)}`;

		this.sendExportRequest(url).subscribe(
			(data) =>
				Utils.generateDownloadFile(
					data,
					'GrievanceType_' + new Date().toDateString() + '.xlsx',
					'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
				),
			handleError
		);
	}
	public exportProgramGridToExcel(state: State): void {
		const url = `api/export/program?${toDataSourceRequestString(state)}`;

		this.sendExportRequest(url).subscribe(
			(data) =>
				Utils.generateDownloadFile(
					data,
					'Program_' + new Date().toDateString() + '.xlsx',
					'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
				),
			handleError
		);
	}
	public exportCategoryGridToExcel(state: State): void {
		const url = `api/export/category?${toDataSourceRequestString(state)}`;

		this.sendExportRequest(url).subscribe(
			(data) =>
				Utils.generateDownloadFile(
					data,
					'Category_' + new Date().toDateString() + '.xlsx',
					'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
				),
			handleError
		);
	}
	
	private sendExportRequest(url: string): Observable<any> {
		this.loading = true;
		const headers = new HttpHeaders({
			'Content-Type': 'application/json',
			Accept: 'application/json',
		});
		return this._http.get(url, { headers, responseType: 'blob' as 'json' }).pipe(tap(this.defaultCompleteHandler));
	}
}
