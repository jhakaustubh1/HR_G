import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DataSourceRequestState, toDataSourceRequestString } from '@progress/kendo-data-query';
import { catchError, map, tap } from 'rxjs/operators';
import { HttpResponseMessage } from '../models/http-response-message.model';
import { GridDataResultPipe } from '../pipes/grid-data-result.pipe';
import { AdminAPI } from './admin.api';
import { handleError } from '../shared/utils';
import { Observable } from 'rxjs';
import Swal from 'sweetalert2';
import { Program } from '../models/program.model';
import { Category } from '../models/category.model';
import { GrievanceType } from '../models/grievance-type.model';
import { BaseService } from './base-service.service';

@Injectable({
	providedIn: 'root',
})
export class AdminService extends BaseService {
	constructor(private _adminApi: AdminAPI, private _gridDataResultPipe: GridDataResultPipe, private _http: HttpClient) {
		super();
	}

	// programs
	public getPrograms(state: DataSourceRequestState) {
		this.readLoading = true;
		const queryStr = `${toDataSourceRequestString(state)}`;
		const destURL = `api/admin/programs?${queryStr}`;

		return this._http
			.get<HttpResponseMessage>(destURL)
			.pipe((r) => this._gridDataResultPipe.transform(r), tap(this.readDataCompleteHandler), catchError(handleError));
	}
	public createProgram(program: Program): Observable<any> {
		this.createLoading = true;
		return this._adminApi.createProgram(program).pipe(
			map((r) => r.Data),
			tap(this.createDataCompleteHandler),
			catchError(handleError)
		);
	}

	public updateProgram(program: Program): Observable<any> {
		this.updateLoading = true;
		return this._adminApi.updateProgram(program).pipe(
			map((r) => r.Data),
			tap(this.updateDataCompleteHandler),
			catchError(handleError)
		);
	}
	public deleteProgram(program: Program): Observable<any> {
		this.updateLoading = true;
		return this._adminApi.deleteProgram(program).pipe(
			map((r) => r.Data),
			tap(this.updateDataCompleteHandler),
			catchError(handleError)
		);
	}

	// grievance-types
	public getGrievanceTypes(state: DataSourceRequestState) {
		this.readLoading = true;
		const queryStr = `${toDataSourceRequestString(state)}`;
		const destURL = `api/admin/grievance-types?${queryStr}`;

		return this._http
			.get<HttpResponseMessage>(destURL)
			.pipe((r) => this._gridDataResultPipe.transform(r), tap(this.readDataCompleteHandler), catchError(handleError));
	}
	public createGrievanceType(grievanceType: GrievanceType): Observable<any> {
		this.createLoading = true;
		return this._adminApi.createGrievanceType(grievanceType).pipe(
			map((r) => r.Data),
			tap(this.createDataCompleteHandler),
			catchError(handleError)
		);
	}

	public updateGrievanceType(grievanceType: GrievanceType): Observable<any> {
		this.updateLoading = true;
		return this._adminApi.updateGrievanceType(grievanceType).pipe(
			map((r) => r.Data),
			tap(this.updateDataCompleteHandler),
			catchError(handleError)
		);
	}
	public deleteGrievanceType(grievanceType: GrievanceType): Observable<any> {
		this.updateLoading = true;
		return this._adminApi.deleteGrievanceType(grievanceType).pipe(
			map((r) => r.Data),
			tap(this.updateDataCompleteHandler),
			catchError(handleError)
		);
	}

	// categories
	public getCategories(state: DataSourceRequestState) {
		this.readLoading = true;
		const queryStr = `${toDataSourceRequestString(state)}`;
		const destURL = `api/admin/categories?${queryStr}`;

		return this._http
			.get<HttpResponseMessage>(destURL)
			.pipe((r) => this._gridDataResultPipe.transform(r), tap(this.readDataCompleteHandler), catchError(handleError));
	}
	public createCategory(category: Category): Observable<any> {
		this.createLoading = true;
		return this._adminApi.createCategory(category).pipe(
			map((r) => r.Data),
			tap(this.createDataCompleteHandler),
			catchError(handleError)
		);
	}

	public updateCategory(category: Category): Observable<any> {
		this.updateLoading = true;
		return this._adminApi.updateCategory(category).pipe(
			map((r) => r.Data),
			tap(this.updateDataCompleteHandler),
			catchError(handleError)
		);
	}
	public deleteCategory(category: Category): Observable<any> {
		this.updateLoading = true;
		return this._adminApi.deleteCategory(category).pipe(
			map((r) => r.Data),
			tap(this.updateDataCompleteHandler),
			catchError(handleError)
		);
	}

	
}
