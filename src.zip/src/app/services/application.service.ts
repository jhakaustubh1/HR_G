import { Injectable } from '@angular/core';
import { ApplicationAPI } from './application.api';
import { catchError, map, publish, refCount, shareReplay, tap } from 'rxjs/operators';
import { LookupType } from '../enums/lookup-type.enum';
import { Lookup } from '../models/lookup.model';
import { Observable } from 'rxjs';
import { BaseService } from './base-service.service';
import { handleError } from '../shared/utils';

@Injectable({
    providedIn: 'root'
})
export class ApplicationService extends BaseService {

    private gnetUser: any;
    private fullUserInfo: any;

    constructor(
        private _api: ApplicationAPI
    ) { super();}

    getApplicationUser(): any {
        if (!this.fullUserInfo) {
            this.fullUserInfo = this._api.getCurrentUser().pipe(shareReplay(1));
        }
        return this.fullUserInfo;
    }

    getGNetUser(): any {
        if (!this.gnetUser) {
            this.gnetUser = this._api.getGNetUser().pipe(shareReplay(1));
        }
        return this.gnetUser;
    }
    getLookupValues(
        lookupType: LookupType,
        filter: string = '',
        getAll: boolean = false,
        publishedOnly = false
    ): Observable<Array<Lookup>> {
        this.addLoader();
        return this._api.getLookupValuesByType(lookupType, filter, getAll, publishedOnly).pipe(
            map((r) => r.Data),
            tap(this.readDataCompleteHandler)
        );
    }
        public getGrievors(grievorName: string): Observable<any> {
            this.readLoading = true;
            return this._api.GetGrievorsFromHeadCount(grievorName).pipe(
                map((r) => r.Data),
                tap(this.readDataCompleteHandler),
                catchError(handleError)
            );
        }
}
