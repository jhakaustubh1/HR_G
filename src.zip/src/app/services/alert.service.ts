import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { SweetAlertOptions, SweetAlertResult } from 'sweetalert2';
import { Validation } from '../models/validation.model';

@Injectable({
    providedIn: 'root'
})
export class AlertService {

    public get sweetAlert$() {
        return this._sweetAlertSource.asObservable();
    }
    private _sweetAlertSource = new BehaviorSubject<AlertOptions>(null as AlertOptions);

    constructor() { }

    triggerSweetAlert(options: AlertOptions): void {
        this._sweetAlertSource.next(options);
    }

    public successPopup(): void{
        this._sweetAlertSource.next({
            swalOptions: {
                title: 'Success',
                icon: 'success',
                showConfirmButton: true,
                confirmButtonText: 'Ok'
            }
        });
    }

    public handleErrors(result: Validation[]) {
        let title = '';
        let text = '';
        let isHtml = false;
        if (result.length > 1) {
            title = 'Multiple validation errors occured.';
            isHtml = true;
            text += '<ul>';
            for (let i = 0; i < result.length; i++) {
                text += '<li>' + result[i].Property + ': ' + result[i].Error + '</li>';
            }
            text += '</ul>';
        } else {
            title = result[0].Property + ' error.';
            text = result[0].Error;
        }
        this._sweetAlertSource.next({
            swalOptions: {
                title,
                text: isHtml ? null : text,
                html: isHtml ? text : null,
                icon: 'error',
                showConfirmButton: true,
                confirmButtonText: 'Ok'
            }
        });
    }
}

export interface AlertOptions {
    swalOptions: SweetAlertOptions;
    callbacks?: CallbackOptions;
}

export interface CallbackOptions {
    then(result: SweetAlertResult<any>): void;
}
