import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DataSourceRequestState, toDataSourceRequestString } from '@progress/kendo-data-query';
import { catchError, map, tap } from 'rxjs/operators';
import { HttpResponseMessage } from '../models/http-response-message.model';
import { GridDataResultPipe } from '../pipes/grid-data-result.pipe';
import { AdminAPI } from './admin.api';
import { handleError } from '../shared/utils';
import { Observable } from 'rxjs';
import Swal from 'sweetalert2';

import { BaseService } from './base-service.service';
import { HRGrievanceAPI } from './hrgrievance.api';
import { HRGrievance } from '../models/hrgrievance.model';

@Injectable({
	providedIn: 'root',
})
export class HRGrievanceService extends BaseService {
	constructor(private _hrGrievanceapi: HRGrievanceAPI,private _gridDataResultPipe: GridDataResultPipe, private _http: HttpClient) {
		super();
	}

	// grievances
	public getGrievances(state: DataSourceRequestState) {
		this.readLoading = true;
		const queryStr = `${toDataSourceRequestString(state)}`;
		const destURL = `api/hr-grievance/hr-grievances?${queryStr}`;

		return this._http
			.get<HttpResponseMessage>(destURL)
			.pipe((r) => this._gridDataResultPipe.transform(r), tap(this.readDataCompleteHandler), catchError(handleError));
	}
	
	public createGrievance(data: FormData): Observable<any> {
			this.createLoading = true;
			return this._hrGrievanceapi.createGrievance(data).pipe(
				map((r) => r.Data),
				tap(this.createDataCompleteHandler),
				catchError(handleError)
			);
		}

		// this.createLoading = true;
		// return this._http.post<HttpResponseMessage>(`api/hrgrievance/hr-grievances`, data).pipe(
		// 	map((r) => r.Data),
		// 	tap(this.createDataCompleteHandler),
		// 	catchError(handleError)
		// );
	//}
	
}
