import { Observable } from "rxjs";
import { HttpResponseMessage } from "../models/http-response-message.model";
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { HRGrievance } from "../models/hrgrievance.model";

@Injectable({
	providedIn: "root",
})
export class HRGrievanceAPI {
	constructor(private _http: HttpClient) {}

  public createGrievance(data: FormData): Observable<HttpResponseMessage> { 
        return this._http.post<HttpResponseMessage>(`api/hr-grievance/hr-grievances`, data)
    }
}
    