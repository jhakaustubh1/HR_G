import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ICategoryLink } from '../gnet-common/toolbar/toolbar.component';

@Injectable({
  providedIn: 'root'
})
export class SubToolbarService {
  public subToolbarReloadSubject = new BehaviorSubject<ICategoryLink[]>(null);

  constructor() { }
}
