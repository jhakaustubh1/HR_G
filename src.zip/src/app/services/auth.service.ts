import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApplicationService } from '../services/application.service';
import { map } from 'rxjs/operators';

@Injectable()
export class AuthService {

    constructor(
        private _applicationService: ApplicationService
    ) { }

    hasAdminPermissions(): Observable<boolean> {
        console.log('in has permissions');
        return this._applicationService.getApplicationUser().pipe(map(
            (response: any) => {
                console.log('In getApplicationUser', response);
                const user = response.GNetUser;
                if (user.UserRoles && user.UserRoles.length > 0) {
                    for (let i = 0; i < user.UserRoles.length; i++) {
                        if (user.UserRoles[i].indexOf('Access Approver') > -1) {
                            return true;
                        }
                    }
                    return false;
                } else {
                    return false;
                }
            }
        ));
    }
}
