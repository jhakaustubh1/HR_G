import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpResponseMessage } from '../models/http-response-message.model';

import { Program } from '../models/program.model';
import { GrievanceType } from '../models/grievance-type.model';
import { Category } from '../models/category.model';

@Injectable({
  providedIn: 'root'
})
export class AdminAPI {

    constructor(
        private _http: HttpClient
    ) {}
    

    public getProgramById(id: number): Observable<HttpResponseMessage> { 
        return this._http.get<HttpResponseMessage>(`api/admin/programs/${id}`)
    }
    public createProgram(program: Program): Observable<HttpResponseMessage> { 
        return this._http.post<HttpResponseMessage>(`api/admin/programs`, program)
    }
    public updateProgram(program: Program): Observable<HttpResponseMessage> { 
        return this._http.put<HttpResponseMessage>(`api/admin/programs`, program)
    }
    public deleteProgram(program: Program): Observable<HttpResponseMessage> { 
        return this._http.put<HttpResponseMessage>(`api/admin/delete-programs`, program)
    }
    public createGrievanceType(grievanceType: GrievanceType): Observable<HttpResponseMessage> { 
        return this._http.post<HttpResponseMessage>(`api/admin/grievance-types`, grievanceType)
    }
    public updateGrievanceType(grievanceType: GrievanceType): Observable<HttpResponseMessage> { 
        return this._http.put<HttpResponseMessage>(`api/admin/grievance-types`, grievanceType)
    }
    public deleteGrievanceType(grievanceType: GrievanceType): Observable<HttpResponseMessage> { 
        return this._http.put<HttpResponseMessage>(`api/admin/delete-grievance-types`, grievanceType)
    }
    public createCategory(category: Category): Observable<HttpResponseMessage> { 
        return this._http.post<HttpResponseMessage>(`api/admin/categories`, category)
    }
    public updateCategory(category: Category): Observable<HttpResponseMessage> { 
        return this._http.put<HttpResponseMessage>(`api/admin/categories`, category)
    }
    public deleteCategory(category: Category): Observable<HttpResponseMessage> { 
        return this._http.put<HttpResponseMessage>(`api/admin/delete-categories`, category)
    }
    
}
