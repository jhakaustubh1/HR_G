﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpResponseMessage } from '../models/http-response-message.model';
import { LookupType } from '../enums/lookup-type.enum';



@Injectable({
  providedIn: 'root'
})
export class ApplicationAPI {

    constructor(
        private _http: HttpClient
    ) {}

    public getSettings(): Observable<HttpResponseMessage> { 
        return this._http.get<HttpResponseMessage>(`api/settings`)
    }
    public getGNetUser(): Observable<HttpResponseMessage> { 
        return this._http.get<HttpResponseMessage>(`api/gnet-user`)
    }
    public getApplicationUser(): Observable<HttpResponseMessage> { 
        return this._http.get<HttpResponseMessage>(`api/user`)
    }
    public getCurrentUser(): Observable<HttpResponseMessage> { 
        return this._http.get<HttpResponseMessage>(`api/current-user`)
    }
    public getLookupValuesByType(lookupType: LookupType, filter: string | null, getAll: boolean, publishedOnly: boolean): Observable<HttpResponseMessage> { 
        return this._http.get<HttpResponseMessage>(`api/lookup?lookupType=${lookupType}&filter=${encodeURIComponent(filter)}&getAll=${getAll}&publishedOnly=${publishedOnly}`);
    }
    public GetGrievorsFromHeadCount(grievorName: string): Observable<HttpResponseMessage> {
        return this._http.get<HttpResponseMessage>(`api/grievors?grievorName=${grievorName}`);
    }
}
