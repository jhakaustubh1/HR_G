import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Program } from '../../models/program.model';
import { Observable } from 'rxjs';
import { BaseEditableGridComponent } from '../../shared/base-editable-grid.component';
import { AlertService } from '../../services/alert.service';
import { AdminService } from '../../services/admin.service';
import { ExportService } from '../../services/export.service';

@Component({
	selector: 'app-programs',
	templateUrl: './programs.component.html',
	styleUrls: ['./programs.component.scss'],
	changeDetection: ChangeDetectionStrategy.Default,
})
export class ProgramsComponent extends BaseEditableGridComponent<Program> implements OnInit{
	constructor(
		private _adminService: AdminService,
		protected alertService: AlertService,
		private _exportService: ExportService
	) {
		super(alertService);
	}

	ngOnInit() {
		this.loadData();
	}
	public loadData(): void {
		this.view = this._adminService.getPrograms(this.gridState);
	}

	public getLoading(): boolean {
		return this._adminService.loading;
	}
	exportToExcel() {
		this._exportService.exportProgramGridToExcel(this.gridState);
	}
	protected getNewModel(): Program {
		return new Program();
	}
	protected getCreateNewHandler(newModel: Program): Observable<any> {
		return this._adminService.createProgram(newModel);
	}
	protected getEditExistingHandler(updatedModel: Program): Observable<any> {
		updatedModel.IsActive = true;
		return this._adminService.updateProgram(updatedModel);
	}
	protected getRemoveHandler(updatedModel: Program): Observable<any> {
		updatedModel.IsActive = false;
		return this._adminService.deleteProgram(updatedModel);
	}
}
