import { Component, OnInit } from '@angular/core';
import { BaseEditableGridComponent } from '../../shared/base-editable-grid.component';
import { Category } from '../../models/category.model';
import { AdminService } from '../../services/admin.service';
import { AlertService } from '../../services/alert.service';
import { CookieService } from 'ngx-cookie-service';
import { Observable } from 'rxjs';
import { ExportService } from '../../services/export.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent extends BaseEditableGridComponent<Category> implements OnInit{

	constructor(
		private _adminService: AdminService,
		protected alertService: AlertService,
		private _exportService: ExportService,
		private _cookieService: CookieService
	) {
		super(alertService);
	}

	ngOnInit() {
		this.loadData();
	}

	public loadData(): void {
		this.view = this._adminService.getCategories(this.gridState);
	}

	public getLoading(): boolean {
		return this._adminService.loading;
	}
	exportToExcel() {
		this._exportService.exportCategoryGridToExcel(this.gridState);
	}
	protected getNewModel(): Category {
		return new Category();
	}
	protected getCreateNewHandler(newModel: Category): Observable<any> {
		return this._adminService.createCategory(newModel);
	}
	protected getEditExistingHandler(updatedModel: Category): Observable<any> {
		updatedModel.IsActive = true;
		return this._adminService.updateCategory(updatedModel);
	}
	protected getRemoveHandler(updatedModel: Category): Observable<any> {
		updatedModel.IsActive = false;
		return this._adminService.deleteCategory(updatedModel);
	}
}

