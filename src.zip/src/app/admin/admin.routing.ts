import { ModuleWithProviders } from '@angular/core';
import { Routes } from '@angular/router';

import { ProgramsComponent } from './programs/programs.component';
import { CategoriesComponent } from './categories/categories.component';
import { GrievanceTypesComponent } from './grievance-types/grievance-types.component';
import { AuthGuard } from '../auth/auth.guard';

export const adminRoutes: Routes = [
    {
        path: 'admin',
        component: ProgramsComponent,
    },
    {
        path: 'admin/programs',
        component: ProgramsComponent,
    },
    {
        path: 'admin/categories',
        component: CategoriesComponent,
    },
    {
        path: 'admin/grievance-types',
        component: GrievanceTypesComponent,
    }
];
