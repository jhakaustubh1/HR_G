import { Component, OnInit } from '@angular/core';
import { BaseEditableGridComponent } from '../../shared/base-editable-grid.component';
import { AlertService } from '../../services/alert.service';
import { Observable } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { GrievanceType } from '../../models/grievance-type.model';
import { AdminService } from '../../services/admin.service';
import { ExportService } from '../../services/export.service';

@Component({
	selector: 'app-grievance-types',
	templateUrl: './grievance-types.component.html',
	styleUrls: ['./grievance-types.component.scss'],
})
export class GrievanceTypesComponent extends BaseEditableGridComponent<GrievanceType> implements OnInit{

	constructor(
		private _adminService: AdminService,
		protected alertService: AlertService,
		private _exportService: ExportService,
		private _cookieService: CookieService
	) {
		super(alertService);
	}

	ngOnInit() {
		this.loadData();
	}

	public loadData(): void {
		this.view = this._adminService.getGrievanceTypes(this.gridState);
	}

	public getLoading(): boolean {
		return this._adminService.loading;
	}
	exportToExcel() {
		this._exportService.exportGrievanceTypeGridToExcel(this.gridState);
	}
	protected getNewModel(): GrievanceType {
		return new GrievanceType();
	}
	protected getCreateNewHandler(newModel: GrievanceType): Observable<any> {
		return this._adminService.createGrievanceType(newModel);
	}
	protected getEditExistingHandler(updatedModel: GrievanceType): Observable<any> {
		updatedModel.IsActive = true;
		return this._adminService.updateGrievanceType(updatedModel);
	}
	protected getRemoveHandler(updatedModel: GrievanceType): Observable<any> {
		updatedModel.IsActive = false;
		return this._adminService.deleteGrievanceType(updatedModel);
	}
}
