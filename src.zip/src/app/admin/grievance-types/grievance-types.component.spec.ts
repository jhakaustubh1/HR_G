import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrievanceTypesComponent } from './grievance-types.component';

describe('GrievanceTypesComponent', () => {
  let component: GrievanceTypesComponent;
  let fixture: ComponentFixture<GrievanceTypesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrievanceTypesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrievanceTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
