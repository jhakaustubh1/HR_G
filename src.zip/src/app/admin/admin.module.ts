import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';


import { CategoriesComponent } from './categories/categories.component';
import { GrievanceTypesComponent } from './grievance-types/grievance-types.component';
import { AdminComponent } from './admin.component';
import { adminRoutes } from './admin.routing';
import { ProgramsComponent } from './programs/programs.component';
import { SharedModule } from '../shared/shared.module';
import { CommonModule } from '@angular/common';

@NgModule({
    imports: [
        RouterModule.forRoot(adminRoutes),
        SharedModule,
        CommonModule,
    ],
    declarations: [
        AdminComponent,
        ProgramsComponent,
        CategoriesComponent,
        GrievanceTypesComponent
    ],
  exports: [
    RouterModule
],
})
export class AdminModule { }
