import {
    Component,
    ViewEncapsulation,
    OnInit,
    HostBinding,
    ViewChild
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { finalize, catchError } from 'rxjs/operators';
import { ApplicationService } from './services/application.service';
import { GNetUser } from './models/gnet-user.model';
import { User } from './models/user.model';
import { GnetUtilitiesService } from './gnet-common/services/gnet-utilities.service';
import { SwalComponent, SwalPortalTargets } from '@sweetalert2/ngx-sweetalert2';
import { CookieService } from 'ngx-cookie-service';
import { gnetLang } from './gnet-common/gnet-lang-select/gnet-lang';
import { handleError } from './shared/utils';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import localeEs from '@angular/common/locales/es';
import { MatSidenav } from '@angular/material/sidenav';

export const HIDDEN_COLUMNS_COOKIE = 'gnet-ms-display-hidden-columns';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
    @HostBinding('class.main-menu-open') isMainMenuOpen: boolean;
    @HostBinding('class.is-loading-gnet-user') isLoadingGnetUser: boolean;
    @ViewChild('developmentEnvironmentSwal', { static: true }) developmentEnvironmentSwal: SwalComponent;
    @ViewChild('sidenav') public permissionDrawer: MatSidenav;

    gnetUser: GNetUser;
    applicationUser: User;
    constructor(
        private _applicationService: ApplicationService,
        public _gnetUtilsService: GnetUtilitiesService,
        public readonly swalTargets: SwalPortalTargets,
        public translateService: TranslateService,
        public cookieService: CookieService,
    ) {
        translateService.addLangs(['en', 'fr', 'es']);
        let defaultLang = 'en';
        if (this.cookieService.check(gnetLang)) {
            defaultLang = this.cookieService.get(gnetLang);
        } else if (navigator && navigator.language && navigator.language.length >= 2) {
            const browserLang = navigator.language.substring(0, 2);
            defaultLang = browserLang;
        }
        translateService.setDefaultLang(defaultLang);
        registerLocaleData(localeFr);
        registerLocaleData(localeEs);
        this.translateService.use(defaultLang);
    }

    ngOnInit() {
        this.isLoadingGnetUser = true;
        this._applicationService.getApplicationUser()
            .pipe(
                finalize(() => {
                    this.isLoadingGnetUser = false;
                }),
                catchError(handleError)
            )
            .subscribe(response => {
                this.gnetUser = response['GNetUser'];
                this.applicationUser = response['ApplicationUser'];
            }, error => {
                console.error(error);
            });

        // show environment popup if not in production
        if (this._gnetUtilsService.isDevelopment) {

            setTimeout(() => {

                this.developmentEnvironmentSwal.fire();
            }, 100);
        }

    }

    toggleSidebarMenu($event): void {
        this.isMainMenuOpen = $event;
    }

    goToLive() {
        window.location.href = 'https://gnet.ca.aero.bombardier.net/';
    }
}
