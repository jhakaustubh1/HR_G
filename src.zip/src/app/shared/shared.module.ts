import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
/* Material */
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatMenuModule } from '@angular/material/menu';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDividerModule } from '@angular/material/divider';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MatTreeModule } from '@angular/material/tree';
import { MatStepperModule } from '@angular/material/stepper';


/* kendo */
import { GanttModule } from '@progress/kendo-angular-gantt';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IntlModule } from '@progress/kendo-angular-intl';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule, PDFModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { FormFieldModule, InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { LayoutModule, PanelBarModule } from '@progress/kendo-angular-layout';
import { PDFExportModule } from '@progress/kendo-angular-pdf-export';
import { PopupModule } from '@progress/kendo-angular-popup';
import { DateInputModule, DateInputsModule } from '@progress/kendo-angular-dateinputs';


/* material custom */
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { CheckNullFilterPipe } from '../pipes/check-null-filter.pipe';
import { ApplicationService } from '../services/application.service';
import { AuthGuard } from '../auth/auth.guard';
import { AuthService } from '../services/auth.service';
import { SubToolbarComponent } from './sub-toolbar/sub-toolbar.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { UploadsModule } from '@progress/kendo-angular-upload';

// AoT requires an exported function for factories
export const HttpLoaderFactory = (httpClienst: HttpClient): TranslateHttpLoader =>
  /*return new TranslateHttpLoader(httpClient);*/
  new TranslateHttpLoader(httpClienst, './assets/i18n/', '.json');

@NgModule({
  declarations: [
    CheckNullFilterPipe,
    SubToolbarComponent,
    FileUploadComponent,

    
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    SweetAlert2Module.forRoot({
      provideSwal: () =>
        import('sweetalert2').then(({ default: swal }) =>
          swal.mixin({
            buttonsStyling: false,
            customClass: {
              confirmButton: 'btn btn-primary',
              cancelButton: 'btn btn-secondary',
              denyButton: 'btn btn-danger',
            },
          })
        ),
      dismissOnDestroy: true,
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    BrowserModule,
    CommonModule,
    BrowserAnimationsModule,
    DialogsModule,
    DateInputModule,
    DateInputsModule,
    MatDialogModule,
    InputsModule,
    HttpClientModule,
    GridModule,
    DropDownsModule,
    MatAutocompleteModule,
    MatInputModule,
    MatCheckboxModule,
    MatListModule,
    MatMenuModule,
    MatSelectModule,
    NgxMatSelectSearchModule,
    MatDatepickerModule,
    MatSidenavModule,
    MatTabsModule,
    MatListModule,
    MatSlideToggleModule,
    MatTreeModule,
    MatRadioModule,
    MatIconModule,
    MatChipsModule,
    MatButtonModule,
    RouterModule,
    MatNativeDateModule,
    SweetAlert2Module,
    PopupModule,
    DragDropModule,
    GanttModule,
    MatChipsModule,
    UploadsModule
  ],
  exports: [
    BrowserAnimationsModule,
    BrowserModule,
    CheckNullFilterPipe,
    FileUploadComponent,
    CommonModule,
    DateInputModule,
    DateInputsModule,
    DialogsModule,
    IntlModule,
    DropDownsModule,
    FormsModule,
    GridModule,
    ButtonsModule,
    InputsModule,
    LabelModule,
    HttpClientModule,
    FormFieldModule,
    LayoutModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatCardModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatFormFieldModule,
    MatInputModule,
    MatMenuModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatSelectModule,
    NgxMatSelectSearchModule,
    MatTabsModule,
    MatTooltipModule,
    MatSlideToggleModule,
    MatSidenavModule,
    MatStepperModule,
    MatChipsModule,
    PDFModule,
    PDFExportModule,
    PanelBarModule,
    ReactiveFormsModule,
    MatIconModule,
    MatTreeModule,
    RouterModule,
    SweetAlert2Module,
    MatRadioModule,
    TranslateModule,
    SubToolbarComponent,
    PopupModule,
    GanttModule,
    UploadsModule
  ],
  providers: [ApplicationService, AuthGuard, AuthService],
})
export class SharedModule {}
