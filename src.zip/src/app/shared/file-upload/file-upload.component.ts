import { Component, Input, OnInit, EventEmitter, Output } from "@angular/core";

@Component({
	selector: "file-upload",
	templateUrl: "./file-upload.component.html",
	styleUrls: ["./file-upload.component.scss"],
})
export class FileUploadComponent implements OnInit {
	@Input() showFileList: boolean = true;
	@Input() uploadMessage: string = "Select Files...";
	@Input() uploadOnSelect: boolean = false;
	@Input() kendoSelectedFiles: any;
	@Output() kendoSelectedFilesChange = new EventEmitter();
	@Output() kSelect = new EventEmitter();
	@Output() kRemove = new EventEmitter();

	constructor(
		//private _boiFileUploadService: BoiFileUploadService
		) {}

	ngOnInit(): void {}

	onKendoFileSelectChange(event: any) {
		this.kendoSelectedFilesChange.emit(event);
	}
	

	// KendoUploadFile() {
	// 	var data = new FormData();
	// 	console.log(this.kendoSelectedFiles);
	// 	this.kendoSelectedFiles.forEach((file) => {
	// 		console.log("file", file.rawFile);
	// 		data.append("files", file.rawFile);
	// 	});
	// 	this._boiFileUploadService.UploadFileAttachments(data).subscribe((data) => {
	// 		console.log("Uploaded successfully");
	// 	});
	// }
}
