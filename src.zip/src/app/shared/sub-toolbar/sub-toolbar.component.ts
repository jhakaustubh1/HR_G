import { Component, OnInit, Input, SimpleChanges, OnChanges, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ICategoryLink } from '../../gnet-common/toolbar/toolbar.component';
import { SubToolbarService } from '../../services/sub-toolbar.service';

@Component({
    selector: 'app-sub-toolbar',
    templateUrl: './sub-toolbar.component.html',
    styleUrls: ['./sub-toolbar.component.scss'],
})
export class SubToolbarComponent implements OnInit, OnChanges, OnDestroy {

    @Input() selMenu: any;
    @Input() categoryLinks: Array<ICategoryLink>;

    public scrollis: boolean;

    public roleChecked: boolean;
    public currentRoute: any;

    public message: any;
    public toggleTab: any;

    public gridSelected: any;
    public firstTime: boolean;

    public activeSubLink: string;

    private subs: Subscription[] = [];
    constructor(
        private _router: Router,
        private _subtoolbarService: SubToolbarService
    ) { }

    ngOnDestroy(): void {
        this.subs.forEach(s => s.unsubscribe());
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.categoryLinks && !changes.categoryLinks.firstChange && changes.categoryLinks.currentValue) {
            this.categoryLinks = changes.categoryLinks.currentValue;
            this.setUrl();
        }
    }

    ngOnInit() {
        //TODO WHY 993?? (could be 990 eeeeh)
        this.scrollis = window.innerWidth < 993;
        this.subs.push(this._subtoolbarService.subToolbarReloadSubject.subscribe(links => {
            this.categoryLinks = links;
            this.setUrl();
        }));
        this.setUrl();
    }

    public setUrl(): void {
        if (this.categoryLinks && this.categoryLinks.some(cl => this._router.url.indexOf(cl.routePath) > -1)) {
            this.activeSubLink = this.categoryLinks.find(cl => this._router.url.indexOf(cl.routePath) > -1).linkName;
        }
    }

    public changeToTab(linkName: string): void {
        this.activeSubLink = linkName;
    }
}
