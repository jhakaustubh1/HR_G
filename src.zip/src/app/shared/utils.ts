import { CompositeFilterDescriptor, FilterDescriptor, GroupResult, isCompositeFilterDescriptor, State } from '@progress/kendo-data-query';
import { Observable, of, throwError } from 'rxjs';
import { switchMap, tap } from 'rxjs/operators';
import Swal from 'sweetalert2';

// flattens an array for filters
export const flatten = (filter: CompositeFilterDescriptor) => {
    const filters = (filter || {}).filters;
    if (filters) {
        return filters.reduce((acc, curr) => acc.concat(isCompositeFilterDescriptor(curr) ? flatten(curr) : [curr]), []);
    }
    return [];
};

export interface IKendoColumn {
    columnName: string;
    columnWidth: number;
    gridName: string;
}

export const remapGroupResult = (d: any): GroupResult =>
    <GroupResult>{ items: d.Items, aggregates: d.Aggregates, field: d.Member, value: d.Key };

const _MS_PER_DAY = 1000 * 60 * 60 * 24;

export const handleError = (error: any): Observable<never> => {
    let customError: '';
    if (error.error) {
        if (error.error.Message) {
            if (error.error.Message !== 'Validation error') {
                Swal.fire({
                    title: error.error.Message,
                    text: error.error.Error,
                    icon: 'error',
                    confirmButtonText: 'Ok',
                    customClass: {
                        confirmButton: 'swal-custom-error-confirm-button btn btn-primary',
                    },
                });
            }
            customError = error.error.Error;
        } else {
            Swal.fire({
                title: 'Error',
                text: 'An uknown server error has occured. Please try again, and if the issue persists, contact GNet team. Thanks!',
                icon: 'error',
                confirmButtonText: 'Ok',
                customClass: {
                    confirmButton: 'swal-custom-error-confirm-button btn btn-primary',
                },
            });
        }
    } else {
        customError = error;
    }
    return throwError(customError || 'Server error');
};

/**
 * Check if HTML element has a specific class
 */
export const hasClass = (el, className) => new RegExp(className).test(el.className);

export const isChildOf = (el, className) => {
    while (el && el.parentElement) {
        if (hasClass(el.parentElement, className)) {
            return true;
        }
        el = el.parentElement;
    }
    return false;
};
interface ObjectWithNestedProperties {
    [key: string]: any;
}

/**
 * Get a property of an object, that might be nested, by using a string path.
 * Example: getNestedPropertyValue({ a: { b: { c: 1 } } }, 'a.b.c') will return 1
 */
export const getNestedPropertyValue = (obj: ObjectWithNestedProperties, path: string): any | undefined => {
    const keys = path.split('.');
    let currentObj = obj;

    for (const key of keys) {
        if (currentObj && typeof currentObj === 'object' && key in currentObj) {
            currentObj = currentObj[key];
        } else {
            return undefined;
        }
    }

    return currentObj;
};
export class Utils {
    public static getDatesBetween(startDate: Date, endDate: Date) {
        const dates = [];
        let currentDate = startDate;
        const direction = startDate < endDate ? 1 : -1;
        while (!isSameDate(currentDate, endDate)) {
            dates.push(new Date(currentDate));
            currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + direction);
        }
        if (!dates.includes(endDate)) {
            dates.push(endDate);
        }
        return dates;
    }
    public static getEnumValueByKey<E>(e: any, key: string): E {
        return (<any>e)[key];
    }

    public static getNameAndValues<T extends number>(e: any) {
        return this.getNames(e).map((n) => ({ name: n, value: e[n] as T }));
    }

    static getNames(e: any) {
        return this.getObjValues(e).filter((v) => typeof v === 'string') as string[];
    }

    static getValues<T extends number>(e: any) {
        return this.getObjValues(e).filter((v) => typeof v === 'number') as T[];
    }

    public static getAllEnumValues<E>(e: any): E[] {
        const keys = Object.keys(e);
        const values = keys.map((k) => e[k as any]).map((v) => <E>(<unknown>v));

        return values;
    }

    /**
     * Some packages (looking at you Sweet Alerts (⩺_⩹) ) the old properties that may be missing from new options
     * This results in unintended behavior such as timer being added to dialogs that required user input, or extra input
     * is added to timed alerts
     * This function finds properties that are missing from new options and explicitly sets them to null
     *
     * @param old object to scan for missing properties
     * @param newOptions object to assign missing keys to
     * @returns Object missing keys assigned
     */
    public static assignObjectWithMissingPropertiesAsNull<T>(old: T, newObj: T): T {
        const oldKeys = Object.keys(old);

        oldKeys.forEach((oldKey) => {
            if (newObj[oldKey] === undefined) {
                newObj[oldKey] = null;
            }
        });
        return Object.assign({}, newObj);
    }

    /**
     * Modifies the state filter descriptior to remove the leading and trailing white space and line terminator characters.
     */
    public static trimFilters(state: State): State {
        if (state.filter) {
            for (let filter of state.filter.filters) {
                if (isCompositeFilterDescriptor(filter)) {
                    filter = this.iterateCompositeFilter(filter, this.trimFilter);
                } else {
                    filter = this.trimFilter(filter);
                }
            }
        }

        return state;
    }

    /**
     * Iterates through the state filterand sort  and applies the mapping function to each filter and sort .
     */
    public static mapSortsAndFiltersFields(state: State, mappingFunction: (field: string) => string): void {
        if (state.filter) {
            Utils.mapFilterFields(state, (filter: FilterDescriptor) => (filter.field = mappingFunction(<string>filter.field)));
        }
        if (state.sort) {
            state.sort.forEach((sort) => {
                sort.field = mappingFunction(sort.field);
            });
        }
    }

    /**
     * Iterates through the state filter and applies the mapping function to each filter.
     */
    public static mapFilterFields(state: State, mappingFunction: (value: any) => any): void {
        if (state.filter) {
            for (let filter of state.filter.filters) {
                if (isCompositeFilterDescriptor(filter)) {
                    filter = this.iterateCompositeFilter(filter, mappingFunction);
                } else {
                    filter = mappingFunction(filter);
                }
            }
        }
    }

    /**
     *
     *
     * Splits a Pascal-Case word into individual words separated by spaces.
     *
     *
     *
     * @param word
     * @returns
     */
    public static splitPascalCase(word): string {
        const wordRe = /($[a-z])|[A-Z][^A-Z]+/g;
        return word.match(wordRe).join(' ');
    }

    /**
     *
     *
     * Splits a camelCase or PascalCase word into individual words separated by spaces.
     *
     *
     *
     * @param word
     * @returns
     */
    public static splitCamelCase(word): string {
        let i;
        let l;
        const capRe = /[A-Z]/;
        const output = [];
        for (i = 0, l = word.length; i < l; i += 1) {
            if (i === 0) {
                output.push(word[i].toUpperCase());
            } else {
                if (i > 0 && capRe.test(word[i])) {
                    output.push(' ');
                }
                output.push(word[i]);
            }
        }
        return output.join('');
    }

    public static getDifferenceInDaysBetweenTwoDates(a: Date, b: Date): number {
        // for some reason, this is necessary
        a = new Date(a.toString());
        b = new Date(b.toString());

        // Discard the time and time-zone information.
        const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
        const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

        return Math.floor((utc2 - utc1) / _MS_PER_DAY);
    }

    public static getDateArrayFromRange(start: Date, end: Date): Date[] {
        const dateArray = [];
        let currentDate = start;

        while (currentDate <= end) {
            dateArray.push(currentDate);
            currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 1);
        }

        return dateArray;
    }

    public static areDatesEqual(left: Date, right: Date): boolean {
        if (!left || left === null) {
            left = new Date(0);
        }
        if (!right || right === null) {
            right = new Date(0);
        }
        left = new Date(left);
        right = new Date(right);

        const k = left.getDate() === right.getDate() && left.getMonth() === right.getMonth() && left.getFullYear() === right.getFullYear();
        return k;
    }

    public static generateDownloadFile(data: Blob, fileName: string, contentType: string) {
        const element = document.createElement('a');
        element.href = URL.createObjectURL(data);
        element.download = fileName;
        document.body.appendChild(element);
        element.click();
    }

    public static iterateCompositeFilter(
        cFilter: CompositeFilterDescriptor,
        callback: (filter: FilterDescriptor, context?: any) => FilterDescriptor,
        context?: any
    ): CompositeFilterDescriptor {
        for (let filter of cFilter.filters) {
            if (isCompositeFilterDescriptor(filter)) {
                this.iterateCompositeFilter(filter, callback);
            } else {
                filter = callback(filter, context);
            }
        }

        return cFilter;
    }

    private static trimFilter(filter: FilterDescriptor): FilterDescriptor {
        if (typeof filter.value === 'string') {
            filter.value = filter.value.trim();
        }
        return filter;
    }

    private static getObjValues(e: any): (number | string)[] {
        return Object.keys(e).map((k) => e[k]);
    }
}
/**
 * check if given date is todays date
 *
 * @param date date to check
 * @returns true if the given date is today
 */
export const isToday = (date: Date): boolean => {
    const today = new Date();
    return date.getDate() === today.getDate() && date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
};

/**
 * Compare dates only
 */
export const isSameDate = (left: Date, right: Date): boolean => {
    left = new Date(left);
    right = new Date(right);
    return left.getDate() === right.getDate() && left.getMonth() === right.getMonth() && left.getFullYear() === right.getFullYear();
};

/**
 * Convert date to UTC
 */
export const getDateAsUTCFromDate = (date: Date): Date => {
    const _userOffset = date.getTimezoneOffset() * 60 * 1000; // user's offset time
    const _centralOffset = 6 * 60 * 60 * 1000; // 6 for central time - use whatever you need
    date = new Date(date.getTime() + _userOffset);
    return date;
};

/**
 * Regardless of given dates timezone, get the same date in UTC
 */
export const forceDateToUTC = (date: Date): Date =>
    new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes()));



/**
 * Regardless of given dates timezone, get the same date in UTC
 */
export const forceMidnight = (date: Date): Date =>
    new Date(new Date(date).getFullYear(), new Date(date).getMonth(), new Date(date).getDate(), 0, 0, 0);


/**
 * use when parsing strings to a number. For example: `const num = parseInt('123', redix)`;
 */
export const redix = 10;

export const defaultGuid = '00000000-0000-0000-0000-000000000000';

export const isValidGuid = (g: string): boolean => g !== undefined && g !== null && g.length === defaultGuid.length && g !== defaultGuid;

export const isGuidEqual = (left: string, right: string): boolean => {
    if (!isValidGuid(left)) {
        left = defaultGuid;
    }
    if (!isValidGuid(right)) {
        right = defaultGuid;
    }

    return left === right || left.toLowerCase() === right.toLowerCase();
};

/**
 * a pipe operator that executes at the very start of subscribe
 */
export const startWithTap =
    <T>(callback: () => void) =>
    (source: Observable<T>) =>
        of({}).pipe(
            tap(callback),
            switchMap((o) => source)
        );

/**
 * Formats string by replacing parameters with the replacements
 *
 * let str = 'this {0} is {1} a test {0} string {2}';
 *
 * str = formatString(str, 'foo', 'bar', 'baz');
 *
 * result: 'this foo is bar a test foo string baz'
 *
 * @param str string to format
 * @param replacements
 * @returns formatted string
 */
export const formatString = (str: string, ...replacements: string[]): string =>
    str.replace(/{(\d+)}/g, (match, number) => (typeof replacements[number] != 'undefined' ? replacements[number] : match));

/**
 * Generates a query param string for use by url parser. Written for LookupService in the back end
 */
export const createProgramSiteFilter = (programId: string, siteId: string): string =>
    createProgramFilter(programId) + '&' + createSiteFilter(siteId);

/**
 * Generates a query param string for use by url parser. Written for LookupService in the back end
 */
export const createProgramFilter = (programId: string): string => 'program=' + programId;

/**
 * Generates a query param string for use by url parser. Written for LookupService in the back end
 */
export const createSiteFilter = (siteId: string): string => 'site=' + siteId;

/**
 * Generates a query param string for use by url parser. Written for LookupService in the back end
 */
export const createWorkCentreGroupFilter = (workCentreGroupId: string): string => {
    if (!isValidGuid(workCentreGroupId)) {
        throw TypeError('workCentreGroup Id must be a valid positive number');
    }
    return 'workCentreGroup=' + workCentreGroupId;
};

/**
 * A recursive copy function that assigns the obj to new copy while breaking all references of an object or array
 *
 * @param obj item to copy
 * @returns copied object with no references to original
 */
export const deepCopy = (obj: any) => {
    let copy: any;

    // Handle the 3 simple types, and null or undefined
    if (null == obj || 'object' != typeof obj) {
        return obj;
    }

    // Handle Date
    if (obj instanceof Date) {
        copy = new Date();
        copy.setTime(obj.getTime());
        return copy;
    }

    // Handle Array
    if (obj instanceof Array) {
        copy = [];
        for (let i = 0, len = obj.length; i < len; i++) {
            copy[i] = deepCopy(obj[i]);
        }
        return copy;
    }

    // Handle Object
    if (obj instanceof Object) {
        copy = {};
        for (const attr in obj) {
            if (obj.hasOwnProperty(attr)) {
                copy[attr] = deepCopy(obj[attr]);
            }
        }
        return copy;
    }

    throw new Error('Unable to copy obj! Its type isn\'t supported.');
};

/**
 * A copy function to assign object without any references (works 99% of the time)
 *
 * @param obj item to copy
 * @returns copied object with no references to original
 */
export const deepCopyAlt = (obj: any) => JSON.parse(JSON.stringify(obj));

export const lowerCaseOfFirstLetter = (val: string) => val.charAt(0).toLowerCase() + val.slice(1);

/**
 *  function that rounds a number up to the next higher multiple of a second number:
 *
 * @param num number to round up
 * @param multiple number to round up against
 * @returns the number or rounded up number
 */
export const roundUpToNextMultiple = (num: number, multiple: number): number => {
    if (num % multiple === 0) {
        // `num` is already a multiple of `multiple`
        return num;
    } else {
        // Calculate the next multiple
        const remainder = num % multiple;
        return num + (multiple - remainder);
    }
};

/**
 *  Accesses the property of an object given its path. Inner properties must be notated as such: `property.innerProperty`
 *
 * @param object object whose property is being accessed
 * @param path path of the property being read (ex: `property.innerProperty`)
 * @returns the access property of the given object
 */
export const accessProperty = <ObjectType>(object: ObjectType, path: string): ObjectType => {
    const keys = path.split('.');
    let result = object;
    for (const key of keys) {
        result = result[key];
    }
    return result;
};

/**
 *
 *
 * Returns the given `obj` without the `property`.
 *
 *
 *
 * @param obj
 * @param property
 *
 * @returns
 */
export const withoutProperty = (obj, property) => {
    const { [property]: unused, ...rest } = obj;

    return rest;
};

/**
 * Get max cookie age as defined by common browsers (Edge, Chrome, etc.), which is 400 days
 *
 * @returns new Date object representing the max cookie expiration date from current date
 */
export const getMaxCookieExpirationDate = (): Date => {
    const maxCookieAge = 400;
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + maxCookieAge);
    return expirationDate;
};
