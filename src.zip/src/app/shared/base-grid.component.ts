import { GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { State } from '@progress/kendo-data-query';
import { Observable } from 'rxjs';
import { Utils } from './utils';

export abstract class BaseGridComponent {

    public view: Observable<GridDataResult>;
    public gridState: State;

    protected defaultState: State = {
        skip: 0,
        take: 20,
        sort: [{
            field: 'Id',
            dir: 'asc'
        }],
        filter: {
            logic: 'and',
            filters: []
        }
    };

    constructor() {
        this.gridState = this.defaultState;
    }

    public refreshGridData(): void {
        this.loadData();
    }

    public clearFilters(): void {
        this.gridState = this.defaultState;
        this.loadData();
    }

    public onStateChange(state: State, grid: GridComponent): void {
        const trimState = Utils.trimFilters(state);
        this.gridState = trimState;
        this.loadData();
    }

    public abstract getLoading(): boolean;

    protected abstract loadData(): void;
}
