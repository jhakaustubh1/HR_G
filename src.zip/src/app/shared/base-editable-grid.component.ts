import { State } from '@progress/kendo-data-query';
import { Observable } from 'rxjs';
import { Base } from '../models/base.model';
import { AlertService } from '../services/alert.service';
import Swal from 'sweetalert2';
import { Utils } from './utils';
import { BaseGridComponent } from './base-grid.component';

export abstract class BaseEditableGridComponent<T extends Base> extends BaseGridComponent {
	public editEnabled: boolean;

	protected editedRowIndex: number;
	protected editedItem: T;

	protected originalCopy: T;

	constructor(protected alertService: AlertService) {
		super();
	}

	public onStateChange(state: State, grid): void {
		const trimState = Utils.trimFilters(state);

		this.closeEditor(grid);
		this.enableRowEdit(false);
		super.onStateChange(state, grid);
	}

	public resetItem(dataItem: any) {
		if (!dataItem) {
			return;
		}

		// find orignal data item
		//console.log('original item', this.originalCopy);
		// revert changes
		this.editedItem = Object.assign(this.originalCopy, dataItem);

		// super.next(this.data);
	}

	public enableRowEdit(enableEdit: boolean): void {
		this.editEnabled = enableEdit;
	}

	public addHandler({ sender }, formInstance) {
		this.enableRowEdit(true);
		formInstance.reset();
		this.closeEditor(sender);
		const newModel: T = this.getNewModel();
		newModel.IsActive = true;

		sender.addRow(newModel);
	}

	public editHandler({ sender, rowIndex, dataItem }) {
		this.enableRowEdit(true);
		this.closeEditor(sender);
		this.editedRowIndex = rowIndex;
		this.originalCopy = dataItem;
		this.editedItem = Object.assign({}, dataItem);
		sender.editRow(rowIndex);
	}

	public cancelHandler({ sender, rowIndex }) {
		this.resetItem(this.editedItem);
		this.enableRowEdit(false);
		this.closeEditor(sender, rowIndex);
	}

	public removeHandler({ dataItem }) {
		Swal.fire({
			title: 'Warning',
			text: 'This will delete the record. Are you sure you want to proceed?',
			showCancelButton: true,
			showConfirmButton: true,
			confirmButtonText: 'Yes',
			cancelButtonText: 'Cancel',
			icon: 'warning',
			customClass: {
				confirmButton: 'swal-custom-error-confirm-button',
			},
		}).then((result) => {
			if (result.isConfirmed == true) {
				this.getRemoveHandler(dataItem).subscribe(
					() => {
						this.alertService.successPopup();
						this.loadData();
					},
					(e) => {
						if (Array.isArray(e)) {
							this.alertService.handleErrors(e);
						}
					}
				);
			}
		});
	}

	public saveHandler({ sender, rowIndex, dataItem, isNew }) {
		this.enableRowEdit(false);

		if (isNew) {
			this.getCreateNewHandler(dataItem).subscribe(
				() => {
					sender.closeRow(rowIndex);
					this.editedRowIndex = undefined;
					this.alertService.successPopup();
					this.loadData();
				},
				(e) => {
					if (Array.isArray(e)) {
						this.alertService.handleErrors(e);
					}
				}
			);
		} else {
			this.getEditExistingHandler(dataItem).subscribe(
				() => {
					this.alertService.successPopup();
					sender.closeRow(rowIndex);
					this.editedRowIndex = undefined;
					this.loadData();
				},
				(e) => {
					if (Array.isArray(e)) {
						this.alertService.handleErrors(e);
					}
				}
			);
		}
	}

	public isActiveChange(event: boolean, dataItem: Base): void {
		dataItem.IsActive = event;
	}

	private closeEditor(grid, rowIndex = this.editedRowIndex) {
		grid.closeRow(rowIndex);
		this.editedRowIndex = undefined;
	}

	protected abstract getNewModel(): T;
	protected abstract getCreateNewHandler(newModel: T): Observable<any>;
	protected abstract getEditExistingHandler(updatedModel: T): Observable<any>;
	protected abstract getRemoveHandler(updatedModel: T): Observable<any>;
}
