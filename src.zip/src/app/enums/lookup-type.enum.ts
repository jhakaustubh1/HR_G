export enum LookupType {
    Users = 1,
    GlobalHeadCountUsers= 2,
}
