import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { mainWorkflowRoutes } from './main-workflow.routing';

import { MainWorkflowComponent } from './main-workflow.component';
import { GrievanceGridComponent } from './grievance-grid/grievance-grid.component';
import { ProcessTwoComponent } from './process-two/process-two.component';
import { SharedModule } from '../shared/shared.module';
import { CreateGrievanceComponent } from './create-grievance/create-grievance.component';

@NgModule({
    imports: [
        RouterModule.forRoot(mainWorkflowRoutes),
        CommonModule,
        SharedModule,
    ],
    exports: [
        RouterModule
    ],
    declarations: [
        MainWorkflowComponent,
        GrievanceGridComponent,
        ProcessTwoComponent,
        CreateGrievanceComponent
    ]
})
export class MainWorkflowModule { }
