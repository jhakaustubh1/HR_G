import { Component, OnChanges, OnDestroy, OnInit } from "@angular/core";
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { HRGrievance } from "../../models/hrgrievance.model";
import { defaultGuid } from "../../shared/utils";
import { Observable } from "rxjs";
import {
  debounceTime,
  distinctUntilChanged,
  filter,
  switchMap,
} from "rxjs/operators";
import { HRGrievanceService } from "../../services/hrgrievance.service";
import { ApplicationService } from "../../services/application.service";
import { GlobalHeadCount } from "../../models/head-count.model";
import { FileUploadComponent } from "../../shared/file-upload/file-upload.component";
import { User } from "../../models/user.model";



@Component({
  selector: "app-create-grievance",
  templateUrl: "./create-grievance.component.html",
  styleUrls: ["./create-grievance.component.scss"],
})
export class CreateGrievanceComponent implements OnInit {
  public isNew = true;
  public createGrievanceFormGroup: FormGroup;
  public filteredGrievors$: Observable<GlobalHeadCount[]>;
  public filteredLeaders$: Observable<GlobalHeadCount[]>;
  kendoSelectedFiles: any = [];
  sourcePath: any;
  applicationUser: User;
  grievors:any=[];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private _hrGrievanceService: HRGrievanceService,
    private _applicationService: ApplicationService,
    private _router: Router,
    private fb :FormBuilder
  ) {}
  ngOnInit(): void {
    this.initForm();

    this.initializeDropdowns();
    this.setUnionRepInfo();
  }
  private initializeDropdowns() {
    this.filteredGrievors$ =
      this.createGrievanceFormGroup.controls.GrievorName.valueChanges.pipe(
        // only fire when input is a string, ignores objects
        filter((input) => typeof input === "string"),
        filter((input) => input !== null),
        debounceTime(500),
        distinctUntilChanged(),
        switchMap((val) => {
          return this._applicationService.getGrievors(val);
        })
      );
    this.filteredLeaders$ =
      this.createGrievanceFormGroup.controls.GrievanceName.valueChanges.pipe(
        // only fire when input is a string, ignores objects
        filter((input) => typeof input === "string"),
        filter((input) => input !== null),
        debounceTime(500),
        distinctUntilChanged(),
        switchMap((val) => {
          return this._applicationService.getGrievors(val);
        })
      );
  }
  public getOptionGrievors(option: GlobalHeadCount) {
    if (option) {
      return option.FullName;
    }
  }
  onSelectedGrievor(selectedGrievorData) {
    this.createGrievanceFormGroup.controls.GrievorClock.setValue(
      selectedGrievorData.PersonId
    );
  }
  onSelectedGrievanceName(selectedLeaderData) {
    this.createGrievanceFormGroup.controls.GrievanceDepartment.setValue(
      selectedLeaderData.DepartmentName
    );
  }
  onKendoFileSelected(event: any) {
    for (let i = 0; i < event.files.length; i++) {
      if (!this.kendoSelectedFiles) {
        this.kendoSelectedFiles = [];
        this.kendoSelectedFiles.push(event.files[i].rawFile);
      } else {
        this.kendoSelectedFiles.push(event.files[i].rawFile);
      }
    }
  }
  onKendoFileRemove(event) {
    //this._methodsService.DeleteBondingCheckAttachment(event.files[0].id).subscribe();
  }
  getLoading(): boolean {
    return this._applicationService.loading;
  }
  saveHRForm() {
    // if (this.validateForm()) {F
    //     this._applicationService.loading(true);
    //     const hrFormData = this.getHRDataFromForm();
    //     hrFormData.Id = Number(this.hrId);
    //     this._hrDetailsService.saveHRDetails(hrFormData).subscribe((savedHrId: any) => {
    //         this.hrId = savedHrId;
    //         //this.getHrData();
    //         Swal.fire({ title: 'Success', text: 'HR form saved successfully!!!', icon: 'success' }).then((a) => {
    //             this._router.navigate(['./hr-details/hrId/' + this.hrId]);
    //         });
    //         this._hrDetailsService.setLoading(false);
    //     });
    // }
  }
  setUnionRepInfo() {
   this._applicationService.getApplicationUser()
               .subscribe(response => {
                   this.applicationUser = response['ApplicationUser'];
                   this.createGrievanceFormGroup.controls.UnionRepName.setValue(this.applicationUser.FullName);
                   this.createGrievanceFormGroup.controls.UnionRepEmail.setValue(this.applicationUser.Email);
                  });
    
  }
  createGrievance() {
    if (this.validateForm()) {
      const data = new FormData();
      const hrFormData = this.getHRDataFromForm();
      data.append("hrGrievance", JSON.stringify(hrFormData));
      this.kendoSelectedFiles.forEach((file) => {
        data.append("files", file);
      });
      this._hrGrievanceService.createGrievance(data).subscribe(a=>{console.log("hey dhjkdhdhjdh",a)});
    }
  }
  private validateForm() {
    Object.keys(this.createGrievanceFormGroup.controls).forEach((field) => {
      const control = this.createGrievanceFormGroup.get(field);
      control?.markAsTouched({ onlySelf: true });
    });
    const isValid =
      this.createGrievanceFormGroup !== undefined &&
      this.createGrievanceFormGroup.valid;
    return isValid;
  }
  btnBack() {
    if (this.sourcePath) this._router.navigate([this.sourcePath]);
    else this._router.navigate(["main/grievance-grid"]);
  }

  private initForm(grievance: HRGrievance = null): void {
    this.createGrievanceFormGroup = this.formBuilder.group({
      Id: new FormControl<string>(this.isNew ? defaultGuid : grievance?.Id, Validators.required),
      UnionRepName: new FormControl<string>(
        grievance?.UnionRepName,
        Validators.required
      ),
      UnionRepEmail: new FormControl<string>(
        grievance?.UnionRepEmail,
        Validators.required
      ),
      // Grievors: new FormControl<GlobalHeadCount[]>(
      //   grievance?.Grievors,
      //   Validators.required
      // ),
      // GrievorName: new FormControl<string>(
      //   grievance?.GrievorName,
      //   Validators.required
      // ),
      // GrievorClock: new FormControl<string>(
      //   grievance?.GrievorClock,
      //   Validators.required
      // ),
      grievers: this.fb.array([this.createGriever()]),
      DateOfIncident: new FormControl<Date>(
        grievance?.DateOfIncident,
        Validators.required
      ),
      UnionDescrAndRemedySought: new FormControl<string>(
        grievance?.UnionDescrAndRemedySought,
        Validators.required
      ),
      GrievanceName: new FormControl<string>(
        grievance?.GrievanceName,
        Validators.required
      ),
      GrievanceDepartment: new FormControl<string>(
        grievance?.GrievanceDepartment,
        Validators.required
      ),

      // ProgramId: new FormControl<string>(scenario?.ProgramId, Validators.required),
      // WorkCentreGroupId: new FormControl<string>(scenario?.WorkCentreGroupId, Validators.required),
      // AircraftGroupId: new FormControl<string>(scenario?.AircraftGroupId, Validators.required),
    });
  }
  createGriever(): FormGroup {
    return this.fb.group({
     grieverName: ['', Validators.required],
     grieverClock: ['', Validators.required],
    });
   }
  getHRDataFromForm(): HRGrievance {
    return {
      GrievanceName:
        this.createGrievanceFormGroup.controls.GrievanceName?.value.FullName,
        GrievanceDepartment:
        this.createGrievanceFormGroup.controls.GrievanceDepartment?.value,
        UnionRepEmail:
        this.createGrievanceFormGroup.controls.UnionRepEmail?.value,
        UnionRepName:
        this.createGrievanceFormGroup.controls.UnionRepName?.value,
        GrievorClock:
        this.createGrievanceFormGroup.controls.GrievorClock?.value.FullName,
        GrievorName:
        this.createGrievanceFormGroup.controls.GrievorName?.value.FullName,
        UnionDescrAndRemedySought:
        this.createGrievanceFormGroup.controls.UnionDescrAndRemedySought?.value,
      DateOfIncident:
        this.createGrievanceFormGroup.controls.DateOfIncident?.value,
      UnionRepo:this.applicationUser,

      // BadgeId: this.hrDetailsFormGroup.controls.badgeId?.value,
      // FirstName: this.hrDetailsFormGroup.controls.firstName?.value,
      // LastName: this.hrDetailsFormGroup.controls.lastName?.value,
      // LocationCode: this.hrDetailsFormGroup.controls.locationCode?.value,
    };
  }
  // createGriever(): FormGroup { 

  //  // return this.formBuilder.group({ GrievorName: ['', Validators.required], GrievorClock: ['', Validators.required], }); 

  // } 

 

  addGrievors(): void { 

    //this.grievors.push(this.createGriever()); 

  } 
}
