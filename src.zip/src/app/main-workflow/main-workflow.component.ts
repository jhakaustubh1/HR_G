import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-main-workflow',
    templateUrl: './main-workflow.component.html',
    styleUrls: ['./main-workflow.component.scss']
})
export class MainWorkflowComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
