import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-process-two',
  templateUrl: './process-two.component.html',
  styleUrls: ['./process-two.component.scss']
})
export class ProcessTwoComponent implements OnInit {
	grievanceForm: FormGroup;
leaderNames: any;
departments: any;
grievanceTypes: any;
grievers: any;
  fb: any;

  constructor(
    private _fb: FormBuilder,
  ) { }

  ngOnInit() {
    this.grievanceForm = this._fb.group({ repName: ['Ramon Gutierrez', Validators.required],

      email: ['ramon.gutierrez@aero.bombardier.com', 

       [Validators.required, Validators.email]],

        grieverName: ['Roger Richards', Validators.required],

         grieverClock: ['1234567', Validators.required],

          grievanceType: ['', Validators.required], 

          grievanceDetails: ['Lorem ipsum dolor sit amet...', Validators.required], 

          leaderName: ['Roger Richards', Validators.required], 

          department: ['Pre Flight', Validators.required] }); 

         
  }

  //  onSubmit() { if (this.grievanceForm.valid) { console.log('Form Submitted:', this.grievanceForm.value); } }

  onSubmit()
  {

  }
  getgrievers(): FormArray { 

    return this.grievanceForm.get('grievers') as FormArray; 

  } 

  createGriever(): FormGroup { 

    return this.fb.group({ grieverName: ['', Validators.required], grieverClock: ['', Validators.required], }); 

  } 

 

  addGriever(): void { 

    this.grievers.push(this.createGriever()); 

  } 

}
