import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainWorkflowComponent } from './main-workflow.component';

describe('MainWorkflowComponent', () => {
  let component: MainWorkflowComponent;
  let fixture: ComponentFixture<MainWorkflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainWorkflowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainWorkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
