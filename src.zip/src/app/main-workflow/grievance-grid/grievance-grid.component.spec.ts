import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrievanceGridComponent } from './grievance-grid.component';

describe('GrievanceGridComponent', () => {
  let component: GrievanceGridComponent;
  let fixture: ComponentFixture<GrievanceGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrievanceGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrievanceGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
