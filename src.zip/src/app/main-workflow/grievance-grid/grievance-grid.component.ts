import { Component, OnInit } from '@angular/core';
import { AlertService } from '../../services/alert.service';
import { CookieService } from 'ngx-cookie-service';
import { ExportService } from '../../services/export.service';
import { HRGrievance } from '../../models/hrgrievance.model';
import { BaseEditableGridComponent } from '../../shared/base-editable-grid.component';
import { Observable } from 'rxjs';
import { HRGrievanceService } from '../../services/hrgrievance.service';

@Component({
  selector: 'app-grievance-grid',
  templateUrl: './grievance-grid.component.html',
  styleUrls: ['./grievance-grid.component.scss']
})


export class GrievanceGridComponent extends BaseEditableGridComponent<HRGrievance> implements OnInit{

  protected getCreateNewHandler(newModel: HRGrievance): Observable<any> {
    throw new Error('Method not implemented.');
  }
  protected getEditExistingHandler(updatedModel: HRGrievance): Observable<any> {
    throw new Error('Method not implemented.');
  }
  protected getRemoveHandler(updatedModel: HRGrievance): Observable<any> {
    throw new Error('Method not implemented.');
  }
  

	constructor(
		private _hrGrievanceService: HRGrievanceService,
		protected alertService: AlertService,
		private _exportService: ExportService,
		private _cookieService: CookieService,
	) {
		super(alertService);
	}

	ngOnInit() {
		this.loadData();
	}

	public loadData(): void {
		this.view = this._hrGrievanceService.getGrievances(this.gridState);
	}

	public getLoading(): boolean {
		return this._hrGrievanceService.loading;
	}
	exportToExcel() {
		//this._exportService.exportGrievanceTypeGridToExcel(this.gridState);
	}
	protected getNewModel(): HRGrievance {
		return new HRGrievance();
	}
	moveToArchive(selectedData:any)
	{

	}
	// protected getCreateNewHandler(newModel: GrievanceType): Observable<any> {
	// 	return this._adminService.createGrievanceType(newModel);
	// }
	// protected getEditExistingHandler(updatedModel: GrievanceType): Observable<any> {
	// 	updatedModel.IsActive = true;
	// 	return this._adminService.updateGrievanceType(updatedModel);
	// }
	// protected getRemoveHandler(updatedModel: GrievanceType): Observable<any> {
	// 	updatedModel.IsActive = false;
	// 	return this._adminService.deleteGrievanceType(updatedModel);
	// }
}
