import { ModuleWithProviders } from '@angular/core';
import { Routes } from '@angular/router';

import { GrievanceGridComponent } from './grievance-grid/grievance-grid.component';
import { ProcessTwoComponent } from './process-two/process-two.component';
import { CreateGrievanceComponent } from './create-grievance/create-grievance.component';

export const mainWorkflowRoutes: Routes = [
    {
        path: 'main',
        children: [
            {
                path: '',
                component: GrievanceGridComponent,
            },
            {
                path: 'grievance-grid',
                component: GrievanceGridComponent,
            },
            {
                path: 'create-grievance',
                component: CreateGrievanceComponent,
            },
            {
                path: 'process-two',
                component: ProcessTwoComponent,
            }

        ]
    }
];

   