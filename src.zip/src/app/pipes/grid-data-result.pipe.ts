import { Injectable, Pipe, PipeTransform } from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs';
import { HttpResponseMessage } from '../models/http-response-message.model';
import { map } from 'rxjs/operators';
/*
 * A nice little pipe to map HttpResponseMessage observable to GridDataResult observable for async kendo grid
*/
@Injectable({ providedIn: 'root' })
export class GridDataResultPipe {
    public transform(value: Observable<HttpResponseMessage>): Observable<GridDataResult> {
        return value.pipe(map(v => {
            const result: GridDataResult = {
                data: v.Data.Data,
                total: v.Data.Total
            };
            return result;
        }));
    }
}
