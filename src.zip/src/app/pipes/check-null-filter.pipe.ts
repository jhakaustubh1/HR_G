import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'checkNullFilter' })
export class CheckNullFilterPipe implements PipeTransform {

    constructor() { }

    transform(value: any): string {

        let newValue;

        // Check if the value is null or contains only spaces
        if (!value || !value.replace(/\s/g, '').length) {
            newValue = 'N/A';
        } else {
            newValue = value;
        }

        return newValue;
    }
}
