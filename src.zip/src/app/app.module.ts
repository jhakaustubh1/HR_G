import { NgModule } from '@angular/core';
import {
    HashLocationStrategy,
    LocationStrategy
} from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app.routing';
import { SharedModule } from './shared/shared.module';
import { GnetCommonModule } from './gnet-common/gnet-common.module';
import { HttpRequestInterceptorService } from './services/http-request-interceptor.service';
import { AppComponent } from './app.component';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { MainWorkflowModule } from './main-workflow/main-workflow.module';
import { AdminModule } from './admin/admin.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        SharedModule,
        GnetCommonModule,
        MainWorkflowModule,
        AdminModule,
        // IMPORTANT! All module imports MUST come BEFORE AppRoutingModule,
        // otherwise, you will spend countless hours figuring out why you get Not Found page when trying to navigate to them
        AppRoutingModule,
        GridModule,
        BrowserAnimationsModule
    ],
    providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: HttpRequestInterceptorService,
            multi: true
        },
        {
            provide: LocationStrategy,
            useClass: HashLocationStrategy
        },
        {
            provide: 'Window',
            useValue: window
        },
        {
            provide: MAT_DATE_LOCALE,
            useValue: 'en-US'
        },
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
